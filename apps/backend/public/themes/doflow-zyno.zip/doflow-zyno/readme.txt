=== Zyno ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4

== Description ==
Zyno is a Digital Marketing theme template for WordPress that supports full site editing and is fully compatible with the Gutenverse plugin. Zyno is perfect for Online Marketing Agency, SEO Agency, Social Media Marketing, Influencer Marketing, Creative Agencies and Digital Studio. You can use the core version and the included Gutenverse to easily create the website you want. We want to make sure that you have the best experience using WordPress to edit your site.

== Changelog ==

= Version 1.0.3 =
* Fixed content width issue

= Version 1.0.2 =
* Theme updated for compatibility with Gutenverse version 3.0.0

= Version 1.0.1 =
* Fixed issue with the search results page

= Version 1.0.0 =
* First release
