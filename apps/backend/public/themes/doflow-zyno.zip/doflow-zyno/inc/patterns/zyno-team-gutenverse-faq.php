<?php
/**
 * Pattern: Zyno FAQ + Contact (DoFlow — accordion PRO rimosso)
 */
return array(
    'title'      => __( 'Zyno FAQ Contact', 'doflow-zyno' ),
    'categories' => array( 'zyno-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1200"},"gap":"no","elementId":"guten-zfaq1","background":{"type":"default","color":{"type":"variable","id":"theme-3"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"90","bottom":"90"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="zfaq1"><section class="wp-block-gutenverse-section guten-element guten-section guten-zfaq1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-zfaq-left","padding":{"Desktop":{"unit":"px","dimension":{"right":"60"}},"Tablet":{"unit":"px","dimension":{"right":"0","bottom":"50"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zfaq-left"><div class="guten-column-wrapper" data-id="zfaq-left">
<!-- wp:gutenverse/advanced-heading {"elementId":"guten-zfaq-h","alignText":{"Desktop":"left"},"text":"{{faq_heading}} ","focusText":"{{faq_focus}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"theme-0"},"mainTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"},"Tablet":{"unit":"px","point":"30"}},"weight":"700","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusColor":{"type":"variable","id":"theme-1"},"focusTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"}},"weight":"700"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"32"}}}} -->
<div class="guten-element guten-advanced-heading guten-zfaq-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{faq_heading}} </span><span class="heading-focus">{{faq_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:details {"style":{"border":{"bottom":{"color":"#e5e9ed","width":"1px","style":"solid"}},"spacing":{"margin":{"bottom":"0px"},"padding":{"top":"20px","bottom":"20px"}}}} --><details class="wp-block-details" style="border-bottom:1px solid #e5e9ed;margin-bottom:0;padding:20px 0;"><summary style="font-family:Plus Jakarta Sans;font-size:16px;font-weight:700;color:#001f4f;">{{faq1_question}}</summary><!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"},"spacing":{"margin":{"top":"12px"}}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;margin-top:12px;">{{faq1_answer}}</p><!-- /wp:paragraph --></details><!-- /wp:details -->

<!-- wp:details {"style":{"border":{"bottom":{"color":"#e5e9ed","width":"1px","style":"solid"}},"spacing":{"margin":{"bottom":"0px"},"padding":{"top":"20px","bottom":"20px"}}}} --><details class="wp-block-details" style="border-bottom:1px solid #e5e9ed;margin-bottom:0;padding:20px 0;"><summary style="font-family:Plus Jakarta Sans;font-size:16px;font-weight:700;color:#001f4f;">{{faq2_question}}</summary><!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"},"spacing":{"margin":{"top":"12px"}}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;margin-top:12px;">{{faq2_answer}}</p><!-- /wp:paragraph --></details><!-- /wp:details -->

<!-- wp:details {"style":{"border":{"bottom":{"color":"#e5e9ed","width":"1px","style":"solid"}},"spacing":{"margin":{"bottom":"0px"},"padding":{"top":"20px","bottom":"20px"}}}} --><details class="wp-block-details" style="border-bottom:1px solid #e5e9ed;margin-bottom:0;padding:20px 0;"><summary style="font-family:Plus Jakarta Sans;font-size:16px;font-weight:700;color:#001f4f;">{{faq3_question}}</summary><!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"},"spacing":{"margin":{"top":"12px"}}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;margin-top:12px;">{{faq3_answer}}</p><!-- /wp:paragraph --></details><!-- /wp:details -->
</div></div><!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-zfaq-right","padding":{"Desktop":{"unit":"px","dimension":{"left":"50"}},"Tablet":{"unit":"px","dimension":{"left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zfaq-right"><div class="guten-column-wrapper" data-id="zfaq-right">
<!-- wp:group {"style":{"color":{"background":"#001f4f"},"border":{"radius":"20px"},"spacing":{"padding":{"top":"40px","bottom":"40px","left":"40px","right":"40px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group has-background" style="background-color:#001f4f;border-radius:20px;padding:40px;">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"26px","fontWeight":"700"},"spacing":{"margin":{"bottom":"24px"}}}} --><h3 class="wp-block-heading has-text-color" style="color:#ffffff;font-family:Plus Jakarta Sans;font-size:26px;font-weight:700;margin-bottom:24px;">{{contact_heading}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px"},"spacing":{"margin":{"bottom":"8px"}}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:15px;margin-bottom:8px;"><strong style="color:#ffffff;">Email</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"16px"},"spacing":{"margin":{"bottom":"24px"}}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:16px;margin-bottom:24px;"><a href="mailto:{{contact_email}}" style="color:#c8e4ff;text-decoration:none;">{{contact_email}}</a></p><!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px"},"spacing":{"margin":{"bottom":"8px"}}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:15px;margin-bottom:8px;"><strong style="color:#ffffff;">Telefono</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"16px"},"spacing":{"margin":{"bottom":"24px"}}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:16px;margin-bottom:24px;">{{contact_phone}}</p><!-- /wp:paragraph -->
<!-- wp:gutenverse/button {"elementId":"guten-zfbtn","content":"{{contact_cta}}","paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"14","bottom":"14","right":"28","left":"28"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-1"}},"buttonBackgroundHover":{"type":"default","color":{"r":255,"g":255,"b":255,"a":1}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"50","right":"50","bottom":"50","left":"50"}}}},"color":{"r":255,"g":255,"b":255,"a":1},"hoverTextColor":{"type":"variable","id":"theme-0"},"typography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"weight":"600"}} -->
<div class="guten-element guten-button-wrapper guten-zfbtn"><a class="guten-button guten-button-sm" href="mailto:{{contact_email}}"><span>{{contact_cta}}</span></a></div>
<!-- /wp:gutenverse/button -->
</div><!-- /wp:group -->
</div></div><!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
