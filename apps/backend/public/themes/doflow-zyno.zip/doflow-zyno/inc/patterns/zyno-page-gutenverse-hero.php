<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Zyno Page Gutenverse Hero', 'zyno' ),
	'categories' => array( 'zyno-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-cmuena","margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="cmuena"><section class="wp-block-gutenverse-section guten-element guten-section guten-cmuena layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-YNNf5H"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-YNNf5H"><div class="guten-column-wrapper" data-id="YNNf5H"><!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1290"},"isChild":true,"elementId":"guten-2kyhcU","background":{"videoPlayOnMobile":false,"type":"default","image":{"Desktop":{"id":64,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/bg-hero.webp"}},"position":{"Desktop":"top center"},"size":{"Desktop":"cover"},"repeat":{"Desktop":"no-repeat"}},"backgroundOverlay":{"type":"gradient","gradientType":"linear","gradientColor":[{"color":"rgba(250, 255, 254, 0)","active":false,"opacity":0,"id":1,"offset":"0.000"},{"color":"rgba(247, 252, 255, 1)","active":true,"opacity":1,"id":2,"offset":"1.000"}],"gradientAngle":180},"opacity":"1","border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"","left":""}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"170","bottom":"100","right":""}},"Tablet":{"unit":"px","dimension":{"top":"120","right":"30","bottom":"100","left":"30"}},"Mobile":{"unit":"px","dimension":{"top":"100","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="2kyhcU"><section class="wp-block-gutenverse-section guten-element guten-section guten-2kyhcU layout-fullwidth align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-4xhqb4"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-4xhqb4"><div class="guten-column-wrapper" data-id="4xhqb4"><!-- wp:gutenverse/section {"isChild":true,"gap":"no","elementId":"guten-rMNLpS","margin":{"Desktop":[],"Tablet":[]},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="section-wrapper" data-id="rMNLpS"><section class="wp-block-gutenverse-section guten-element guten-section guten-rMNLpS layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-51bgZD","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Tablet":"center","Mobile":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-51bgZD"><div class="guten-column-wrapper" data-id="51bgZD"><!-- wp:gutenverse/post-title {"elementId":"guten-Zpz968","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"mAEKo5","spacing":{"Desktop":"-.02"},"size":{"Desktop":{"point":"60","unit":"px"},"Tablet":{"point":"50","unit":"px"},"Mobile":{"point":"38","unit":"px"}},"weight":"600","font":{"label":"Poppins","value":"Poppins","type":"google"}},"color":{"type":"variable","id":"theme-0"}} -->
<div class="guten-element guten-post-title guten-Zpz968"></div>
<!-- /wp:gutenverse/post-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
