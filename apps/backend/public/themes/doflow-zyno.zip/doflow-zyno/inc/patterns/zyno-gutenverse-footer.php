<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Zyno Gutenverse Footer', 'zyno' ),
	'categories' => array( 'zyno-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1290"},"gap":"no","elementId":"guten-5eNMxN","margin":{"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Desktop":[]},"padding":{"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Desktop":[]}} -->
<div class="section-wrapper" data-id="5eNMxN"><section class="wp-block-gutenverse-section guten-element guten-section guten-5eNMxN layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-5MazNz","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"0","left":"20"}},"Tablet":[],"Mobile":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-5MazNz"><div class="guten-column-wrapper" data-id="5MazNz"><!-- wp:gutenverse/section {"width":{"Desktop":"700"},"isChild":true,"elementId":"guten-xNDcmz","background":{"videoPlayOnMobile":false,"type":"gradient","gradientColor":[{"color":"rgba(1, 23, 44, 1)","opacity":1,"active":false,"id":1,"offset":"0.000"},{"color":"rgba(0, 39, 96, 1)","active":true,"opacity":1,"id":2,"offset":"1.000"}]},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"0","left":"0"}}}},"margin":{"Desktop":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"50","bottom":"170"}},"Mobile":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"120","left":"20"}}},"mask":{"shape":"custom","svg":{"id":189,"image":"https://designer.gutenverse.com/zyno/wp-content/uploads/sites/76/2024/10/footer-masking-shape.png"},"size":{"Desktop":"custom","Tablet":"cover"},"position":{"Desktop":"top center","Tablet":"center right","Mobile":"center center"},"repeat":{"Desktop":"no-repeat"},"scale":{"Desktop":{"unit":"%","point":"100"},"Tablet":{"unit":"%","point":"100"}},"xposition":{"Desktop":{"point":"","unit":"px"}}}} -->
<div class="section-wrapper" data-id="xNDcmz"><section class="wp-block-gutenverse-section guten-element guten-section guten-xNDcmz layout-boxed align-stretch"><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-ZMQOLN","horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-ZMQOLN"><div class="guten-column-wrapper" data-id="ZMQOLN"><!-- wp:gutenverse/heading {"elementId":"guten-14vzuQ","textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"white"},"typography":{"type":"variable","id":"4jlV7B","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"48","unit":"px"}},"spacing":{"Desktop":"-.02"},"weight":"600"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"80"}}},"padding":{"Desktop":[]},"animation":{"type":{"Desktop":"fadeIn"}},"positioningType":{"Desktop":"default"},"positioningWidth":{"Desktop":{"point":"1000","unit":"px"}}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-14vzuQ animated guten-element-hide desktop-fadeIn">Subscribe Now for Exclusive Updates and Offers Today</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/form-builder {"elementId":"guten-za2GZJ","formId":{"label":"Subscribe Form","value":200},"successAlign":{"Desktop":null,"Mobile":"center"},"successPadding":{"Desktop":[],"Mobile":[]},"successMargin":{"Desktop":[],"Mobile":[]},"successBorder":{"radius":{"Desktop":[],"Mobile":[]}},"successBorderResponsive":{"Desktop":{"radius":[]},"Mobile":{"radius":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-60","left":"60","bottom":"","right":"60"}},"Mobile":{"unit":"px","dimension":{"top":"-50","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":[],"Mobile":[]}} -->
<form style="display:none" class="guten-element guten-form-builder guten-za2GZJ" data-form-id="200"><!-- wp:gutenverse/form-input-email {"elementId":"guten-J7BcNN","showLabel":false,"showHelper":false,"labelWidth":{"Desktop":""},"labelPadding":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Mobile":[]},"labelMargin":{"Desktop":[],"Mobile":[]},"helperPadding":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Mobile":[]},"positioningType":{"Desktop":"custom","Mobile":"full"},"positioningWidth":{"Desktop":{"point":"394","unit":"px"}},"positioningAlign":{"Desktop":"center"},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10"}}},"padding":{"Desktop":[]},"inputPlaceholder":"Enter your email","inputPadding":{"Desktop":{"unit":"px","dimension":{"top":"12","right":"12","bottom":"12","left":"18"}},"Mobile":[]},"inputMargin":{"Desktop":[],"Mobile":[]},"placeholderColor":{"Desktop":{"type":"variable","id":"theme-4"}},"inputTypography":{"type":"variable","id":"qmdrZl","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"inputColorNormal":{"Desktop":{"type":"variable","id":"theme-4"}},"inputBorderNormal":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"10","right":"10","bottom":"10","left":"10"}}},"all":{"type":"solid","width":1,"color":{"type":"variable","id":"theme-2"}}},"inputBorderNormalResponsive":{"Mobile":{"radius":[]}},"inputBorderHover":{"radius":{"Desktop":[]}},"inputBorderFocus":{"radius":{"Desktop":[]},"all":{"type":"solid","width":1,"color":{"type":"variable","id":"theme-1"}}},"inputBgColorNormal":{"Desktop":{"type":"variable","id":"white"}}} -->
<div class="guten-element guten-form-input-email guten-form-input guten-input-position-top guten-J7BcNN hide-label hide-helper"><div class="label-wrapper"></div><div class="main-wrapper"><input data-validation="{&quot;type&quot;:&quot;email&quot;,&quot;required&quot;:false,&quot;validationType&quot;:&quot;none&quot;,&quot;validationWarning&quot;:&quot;Input Invalid&quot;}" placeholder="Enter your email" name="input-email" class="gutenverse-input gutenverse-input-email" type="email"/><div class="validation-error">Input Invalid</div></div></div>
<!-- /wp:gutenverse/form-input-email -->

<!-- wp:gutenverse/form-input-submit {"elementId":"guten-APocDa","content":"Subscribe","buttonWidth":{"Mobile":"100"},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-1"}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"theme-6"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"8","right":"8","bottom":"8","left":"8"}}}},"positioningType":{"Desktop":"inline","Mobile":"full"},"positioningWidth":{"Desktop":{"point":"","unit":"px"}},"positioningAlign":{"Desktop":"center"},"background":{"type":"gradient","gradientColor":[{"color":"rgba(112, 152, 255, 1)","opacity":1,"active":true,"id":1,"offset":"0.000"},{"color":"rgba(0, 71, 255, 1)","active":false,"opacity":1,"id":2,"offset":"1.000"}],"gradientType":"linear"},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"13","right":"13","bottom":"13","left":"13"}}}},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"4","right":"4","bottom":"4","left":"4"}}},"color":{"type":"variable","id":"white"},"typography":{"type":"variable","id":"l1IF9b","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"500","spacing":{"Desktop":"-.02"}},"alignButton":{"Mobile":"center"},"paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"16","right":"30","bottom":"16","left":"30"}},"Mobile":[]}} -->
<div class="guten-element guten-button-wrapper guten-submit-wrapper guten-APocDa"><div class="form-notification"></div><button class="guten-button gutenverse-input-submit guten-button-sm" type="submit"><span>Subscribe</span></button><div class="gutenverse-input-submit-loader"><i class="fas fa-spinner fa-spin"></i></div></div>
<!-- /wp:gutenverse/form-input-submit --></form>
<!-- /wp:gutenverse/form-builder --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --><!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-Jfb0jy","margin":{"Desktop":{"unit":"px","dimension":{"top":"-100"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="Jfb0jy"><section class="wp-block-gutenverse-section guten-element guten-section guten-Jfb0jy layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-LwqIIT"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-LwqIIT"><div class="guten-column-wrapper" data-id="LwqIIT"><!-- wp:gutenverse/section {"width":{"Desktop":"1290"},"isChild":true,"gap":"no","elementId":"guten-Bbn41y","background":{"videoPlayOnMobile":false,"type":"gradient","gradientColor":[{"color":"rgba(237, 247, 255, 1)","opacity":1,"active":false,"id":1,"offset":"0.000"},{"color":"rgba(255, 255, 255, 1)","active":true,"opacity":1,"id":2,"offset":"1.000"}],"gradientType":"linear"},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20"}}}}} -->
<div class="section-wrapper" data-id="Bbn41y"><section class="wp-block-gutenverse-section guten-element guten-section guten-Bbn41y layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-XyUzH8","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"80","right":"0","bottom":"0","left":"0"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"40","right":"10","bottom":"10","left":"10"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-XyUzH8"><div class="guten-column-wrapper" data-id="XyUzH8"><!-- wp:gutenverse/section {"width":{"Desktop":"1290"},"isChild":true,"elementId":"guten-kgczks"} -->
<div class="section-wrapper" data-id="kgczks"><section class="wp-block-gutenverse-section guten-element guten-section guten-kgczks layout-boxed align-stretch"><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":41,"Tablet":100,"Mobile":null},"elementId":"guten-zqyySU","horizontalAlign":{"Desktop":"default","Tablet":"center"},"margin":{"Tablet":{"unit":"px","dimension":{"bottom":"20"}},"Mobile":[]},"padding":{"Tablet":[],"Mobile":{"unit":"px","dimension":{"right":"20","left":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zqyySU"><div class="guten-column-wrapper" data-id="zqyySU"><!-- wp:gutenverse/image {"elementId":"guten-pUArAS","imgSrc":{"media":{"imageId":51,"sizes":{"thumbnail":{"height":150,"width":150,"url":"https://designer.gutenverse.com/zyno-lite/wp-content/uploads/sites/76/2024/10/zyno-logo.webp","orientation":"landscape"},"medium":{"height":127,"width":300,"url":"https://designer.gutenverse.com/zyno-lite/wp-content/uploads/sites/76/2024/10/zyno-logo.webp","orientation":"landscape"},"full":{"url":"https://designer.gutenverse.com/zyno-lite/wp-content/uploads/sites/76/2024/10/zyno-logo.webp","height":311,"width":732,"orientation":"landscape"}}},"size":"full"},"altOriginal":"","captionOriginal":"","width":{"Desktop":{"unit":"px","point":"120"}},"imgBorder":{"radius":{"Desktop":[]}},"imgBorderResponsive":{"Tablet":{"radius":[]}},"align":{"Desktop":"left","Tablet":"center"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":""}}},"positioningType":{"Desktop":"custom"},"positioningWidth":{"Desktop":{"point":"","unit":"px"}}} -->
<div class="wp-block-gutenverse-image guten-element guten-image guten-pUArAS"><div class="guten-image-wrapper"><img class="gutenverse-image-box-filled" src="https://designer.gutenverse.com/zyno-lite/wp-content/uploads/sites/76/2024/10/zyno-logo.webp" height="311" width="732"/></div></div>
<!-- /wp:gutenverse/image -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-Gj9mtP","alignment":{"Tablet":"center"},"textColor":{"type":"variable","id":"theme-4"},"typography":{"type":"variable","id":"qmdrZl","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":"15","bottom":"25"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"custom","Tablet":"custom"},"positioningWidth":{"Desktop":{"point":"315","unit":"px"},"Tablet":{"point":"455","unit":"px"}}} -->
<div class="guten-element gutenverse-text-editor guten-Gj9mtP"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Lorem ipsum dolor amet, consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/social-icons {"elementId":"guten-qzPBdH","iconSize":{"Desktop":{"point":"18","unit":"px"}},"gap":{"Desktop":"22"},"alignment":{"Desktop":"flex-start","Tablet":"center"},"shape":"square","iconColor":{"type":"variable","id":"theme-1"},"bgColor":{"r":0,"g":0,"b":0,"a":0},"itemPadding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"positioningAlign":{"Desktop":"center"}} -->
<div class="guten-element guten-social-icons guten-qzPBdH square horizontal fill"><!-- wp:gutenverse/social-icon {"elementId":"guten-zSUTtm"} -->
<div class="guten-element guten-social-icon guten-zSUTtm facebook"><a id="guten-zSUTtm" href="#"><i class="gtn gtn-facebook-light"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-naJItx"} -->
<div class="guten-element guten-social-icon guten-naJItx twitter"><a id="guten-naJItx" href="#"><i class="fab fa-x-twitter"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-EOs9SI"} -->
<div class="guten-element guten-social-icon guten-EOs9SI link"><a id="guten-EOs9SI" href="#"><i class="fab fa-linkedin-in"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-bASglp"} -->
<div class="guten-element guten-social-icon guten-bASglp instagram"><a id="guten-bASglp" href="#"><i class="fab fa-instagram-square"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-jl8oIl"} -->
<div class="guten-element guten-social-icon guten-jl8oIl telegram"><a id="guten-jl8oIl" href="#"><i class="fab fa-telegram"></i></a></div>
<!-- /wp:gutenverse/social-icon --></div>
<!-- /wp:gutenverse/social-icons --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":19.9,"Tablet":"33"},"elementId":"guten-G3PfiE"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-G3PfiE"><div class="guten-column-wrapper" data-id="G3PfiE"><!-- wp:gutenverse/heading {"elementId":"guten-Q1iP6d","color":{"type":"variable","id":"theme-0"},"typography":{"type":"variable","id":"zzuzIj","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"20","unit":"px"}},"weight":"600","spacing":{"Desktop":"-.02"}},"containsAnchorTag":false,"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"left":"5"}}}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-Q1iP6d">Quick Links</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-WhLmJm","spaceBetween":{"Desktop":"15"},"iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"theme-4"},"textColorHover":{"type":"variable","id":"theme-1"},"textTypography":{"type":"variable","id":"qmdrZl","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"left":""}}}} -->
<div class="guten-element guten-icon-list guten-WhLmJm"><div class=" list-wrapper "><!-- wp:gutenverse/icon-list-item {"elementId":"guten-5OyJiM","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-5OyJiM"><div class="list-divider"></div><a id="guten-5OyJiM" href="#"><i class="fas fa-check"></i><span class="list-text ">Home</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-TkUQwt","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-TkUQwt"><div class="list-divider"></div><a id="guten-TkUQwt" href="#"><i class="fas fa-check"></i><span class="list-text ">About</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-PGekda","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-PGekda"><div class="list-divider"></div><a id="guten-PGekda" href="#"><i class="fas fa-check"></i><span class="list-text ">Services</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-1NLuAn","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-1NLuAn"><div class="list-divider"></div><a id="guten-1NLuAn" href="#"><i class="fas fa-check"></i><span class="list-text ">Careers</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":19.5,"Tablet":32},"elementId":"guten-vta4Nr"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-vta4Nr"><div class="guten-column-wrapper" data-id="vta4Nr"><!-- wp:gutenverse/heading {"elementId":"guten-7t8UkE","color":{"type":"variable","id":"theme-0"},"typography":{"type":"variable","id":"zzuzIj","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"20","unit":"px"}},"weight":"600","spacing":{"Desktop":"-.02"}},"containsAnchorTag":false,"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"left":"5"}}}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-7t8UkE">Support</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-bSP8l8","spaceBetween":{"Desktop":"15"},"iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"theme-4"},"textColorHover":{"type":"variable","id":"theme-1"},"textTypography":{"type":"variable","id":"qmdrZl","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"left":""}}}} -->
<div class="guten-element guten-icon-list guten-bSP8l8"><div class=" list-wrapper "><!-- wp:gutenverse/icon-list-item {"elementId":"guten-QOJpuD","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-QOJpuD"><div class="list-divider"></div><a id="guten-QOJpuD" href="#"><i class="fas fa-check"></i><span class="list-text ">Contact Us</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-RE6foX","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-RE6foX"><div class="list-divider"></div><a id="guten-RE6foX" href="#"><i class="fas fa-check"></i><span class="list-text ">Support</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-LaHaAz","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-LaHaAz"><div class="list-divider"></div><a id="guten-LaHaAz" href="#"><i class="fas fa-check"></i><span class="list-text ">Documentation</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-RlTlQG","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-RlTlQG"><div class="list-divider"></div><a id="guten-RlTlQG" href="#"><i class="fas fa-check"></i><span class="list-text ">FAQ</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":19.6,"Tablet":35,"Mobile":null},"elementId":"guten-tfqSQd","margin":{"Desktop":[],"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Tablet":[]},"padding":{"Desktop":{"unit":"px","dimension":{"left":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Tablet":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-tfqSQd"><div class="guten-column-wrapper" data-id="tfqSQd"><!-- wp:gutenverse/heading {"elementId":"guten-uPU4jx","color":{"type":"variable","id":"theme-0"},"typography":{"type":"variable","id":"zzuzIj","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"20","unit":"px"}},"weight":"600","spacing":{"Desktop":"-.02"}},"containsAnchorTag":false,"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"left":"5"}}}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-uPU4jx">Contact Info</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-15i8a1","spaceBetween":{"Desktop":"15"},"iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"theme-4"},"textColorHover":{"type":"variable","id":"theme-1"},"textTypography":{"type":"variable","id":"qmdrZl","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"left":""}}}} -->
<div class="guten-element guten-icon-list guten-15i8a1"><div class=" list-wrapper "><!-- wp:gutenverse/icon-list-item {"elementId":"guten-BUB2Fz"} -->
<div class="guten-element guten-icon-list-item guten-BUB2Fz"><div class="list-divider"></div><a id="guten-BUB2Fz"><i class="fas fa-check"></i><span class="list-text ">Mon-Sat : 8:00 AM - 5:00 PM</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-o8BKsQ"} -->
<div class="guten-element guten-icon-list-item guten-o8BKsQ"><div class="list-divider"></div><a id="guten-o8BKsQ"><i class="fas fa-check"></i><span class="list-text ">Jl. Raya Mas Ubud, Gianyar</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-DP7TTl","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-DP7TTl"><div class="list-divider"></div><a id="guten-DP7TTl" href="#"><i class="fas fa-check"></i><span class="list-text ">admin@support.com</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-YZeB5H","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-YZeB5H"><div class="list-divider"></div><a id="guten-YZeB5H" href="#"><i class="fas fa-check"></i><span class="list-text ">+62 21 2345 6789</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->

<!-- wp:gutenverse/section {"width":{"Desktop":"1290"},"isChild":true,"elementId":"guten-4Hmsak","margin":{"Desktop":{"unit":"px","dimension":{"top":"90"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="section-wrapper" data-id="4Hmsak"><section class="wp-block-gutenverse-section guten-element guten-section guten-4Hmsak layout-boxed align-stretch"><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-hXu2cv","verticalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-hXu2cv"><div class="guten-column-wrapper" data-id="hXu2cv"><!-- wp:gutenverse/heading {"elementId":"guten-4Sotd7","type":6,"textAlign":{"Tablet":"center","Mobile":"center"},"color":{"type":"variable","id":"theme-4"},"typography":{"font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"weight":"400"},"containsAnchorTag":true,"linkColor":{"type":"variable","id":"theme-0"},"linkColorHover":{"type":"variable","id":"theme-1"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"0","left":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"textChilds":[{"color":{"r":0,"g":31,"b":79,"a":1},"colorHover":[],"typography":[],"typographyHover":[],"textClip":[],"textClipHover":[],"background":[],"backgroundHover":[],"padding":[],"paddingHover":[],"margin":[],"marginHover":[],"value":[],"id":"guten-5Vo3tv","spanId":"guten-e2uF4k","_key":"EjRK3d","borderNormal":{"Desktop":{"radius":[]}}}],"openChild":"guten-5Vo3tv"} -->
<h6 class="wp-block-gutenverse-heading guten-element guten-4Sotd7">Copyright © 2025&nbsp;Zyno<span id="guten-e2uF4k"><span class="guten-text-highlight guten-iTex3f" id="guten-5Vo3tv">.</span></span> Powered by&nbsp;<a href="https://gutenverse.com/" data-type="link" data-id="https://gutenverse.com/" target="_blank" rel="noreferrer noopener">Gutenverse Blocks Addons</a>.</h6>
<!-- /wp:gutenverse/heading --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-uUUDYM","verticalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-uUUDYM"><div class="guten-column-wrapper" data-id="uUUDYM"><!-- wp:gutenverse/icon-list {"elementId":"guten-qyKPF0","displayInline":true,"spaceBetween":{"Desktop":"40","Tablet":"","Mobile":"25"},"alignList":{"Desktop":"flex-end","Tablet":"center"},"iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"theme-4"},"textColorHover":{"type":"variable","id":"theme-1"},"textTypography":{"font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"weight":"400","decoration":"underline"},"margin":{"Desktop":{"unit":"px","dimension":{"left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"left":""}}}} -->
<div class="guten-element guten-icon-list guten-qyKPF0"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-K8y40i","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-K8y40i"><div class="list-divider"></div><a id="guten-K8y40i" href="#"><i class="fas fa-check"></i><span class="list-text ">Privacy Policy</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-EvSKKa","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-EvSKKa"><div class="list-divider"></div><a id="guten-EvSKKa" href="#"><i class="fas fa-check"></i><span class="list-text ">Support</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-ToJsOX","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-ToJsOX"><div class="list-divider"></div><a id="guten-ToJsOX" href="#"><i class="fas fa-check"></i><span class="list-text ">Term of Services</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '[{"name":"footer-masking-shape.png","image_url":"https:\/\/designer.gutenverse.com\/zyno\/wp-content\/uploads\/sites\/76\/2024\/10\/footer-masking-shape.png","type":"sync","id":668,"image_id":189},{"name":"zyno-logo.webp","image_url":"https:\/\/designer.gutenverse.com\/zyno-lite\/wp-content\/uploads\/sites\/76\/2024\/10\/zyno-logo.webp","type":"sync","id":668,"image_id":51}]',
	'is_sync' => true,
);
