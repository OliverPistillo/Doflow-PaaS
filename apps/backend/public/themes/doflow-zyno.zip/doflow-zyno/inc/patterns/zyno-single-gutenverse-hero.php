<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Zyno Single Gutenverse Hero', 'zyno' ),
	'categories' => array( 'zyno-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-cmuena","margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="cmuena"><section class="wp-block-gutenverse-section guten-element guten-section guten-cmuena layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-YNNf5H"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-YNNf5H"><div class="guten-column-wrapper" data-id="YNNf5H"><!-- wp:gutenverse/section {"width":{"Desktop":"900"},"isChild":true,"elementId":"guten-2kyhcU","background":{"videoPlayOnMobile":false,"type":"default","image":{"Desktop":{"id":152,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/dot-bg-2.webp"}},"position":{"Desktop":"default"},"size":{"Desktop":"custom"},"repeat":{"Desktop":"repeat-x"},"width":{"Desktop":{"unit":"%","point":"70"}}},"backgroundOverlay":{"type":"gradient","gradientType":"linear","gradientColor":[{"color":"rgba(247, 252, 255, 1)","active":false,"opacity":1,"id":2,"offset":"0.000"},{"color":"rgba(250, 255, 254, 0)","active":false,"opacity":0,"id":1,"offset":"0.511"},{"color":"rgba(255, 255, 255, 1)","active":true,"opacity":1,"id":3,"offset":"1.000"}],"gradientAngle":180},"opacity":"1","border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"","left":""}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"170","bottom":"100","right":""}},"Tablet":{"unit":"px","dimension":{"top":"120","right":"30","bottom":"100","left":"30"}},"Mobile":{"unit":"px","dimension":{"top":"100","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="2kyhcU"><section class="wp-block-gutenverse-section guten-element guten-section guten-2kyhcU layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-4xhqb4"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-4xhqb4"><div class="guten-column-wrapper" data-id="4xhqb4"><!-- wp:gutenverse/section {"isChild":true,"gap":"no","elementId":"guten-rMNLpS","margin":{"Desktop":[],"Tablet":[]},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="section-wrapper" data-id="rMNLpS"><section class="wp-block-gutenverse-section guten-element guten-section guten-rMNLpS layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-51bgZD","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Tablet":"center","Mobile":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-51bgZD"><div class="guten-column-wrapper" data-id="51bgZD"><!-- wp:gutenverse/post-terms {"elementId":"guten-YudU7b","linkTo":"term","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"l1IF9b","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"15","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"500","spacing":{"Desktop":"-.02"}},"color":{"type":"variable","id":"theme-0"},"border":{"radius":{"Desktop":[]}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-terms guten-YudU7b"></div>
<!-- /wp:gutenverse/post-terms -->

<!-- wp:gutenverse/heading {"elementId":"guten-T8J7vf","color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"ZFTe0L","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"},"Mobile":{"point":"13","unit":"px"},"Tablet":{"point":"14","unit":"px"}},"weight":"500"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"9","right":"10","left":"10"}}},"positioningType":{"Desktop":"inline"},"positioningAlign":{"Desktop":"center"}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-T8J7vf">/</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/post-author {"elementId":"guten-dUHsPA","typography":{"type":"variable","id":"l1IF9b","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"15","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"500","spacing":{"Desktop":"-.02"}},"color":{"type":"variable","id":"theme-4"},"authorBorder":{"radius":{"Desktop":[]}},"authorBorderResponsive":{"Desktop":{"radius":[]}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-author guten-dUHsPA"></div>
<!-- /wp:gutenverse/post-author -->

<!-- wp:gutenverse/heading {"elementId":"guten-y8OC1m","color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"ZFTe0L","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"},"Mobile":{"point":"13","unit":"px"},"Tablet":{"point":"14","unit":"px"}},"weight":"500"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"9","right":"10","left":"10"}}},"positioningType":{"Desktop":"inline"},"positioningAlign":{"Desktop":"center"}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-y8OC1m">/</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/post-date {"elementId":"guten-BwRCfs","typography":{"type":"variable","id":"l1IF9b","font":{"label":"Poppins","value":"Poppins","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"15","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"weight":"500","spacing":{"Desktop":"-.02"}},"color":{"type":"variable","id":"theme-4"},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-BwRCfs"></div>
<!-- /wp:gutenverse/post-date -->

<!-- wp:gutenverse/post-title {"elementId":"guten-DX9aOi","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"mAEKo5","spacing":{"Desktop":"-.02"},"size":{"Desktop":{"point":"60","unit":"px"},"Tablet":{"point":"50","unit":"px"},"Mobile":{"point":"38","unit":"px"}},"weight":"600","font":{"label":"Poppins","value":"Poppins","type":"google"}},"color":{"type":"variable","id":"theme-0"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":[]}} -->
<div class="guten-element guten-post-title guten-DX9aOi"></div>
<!-- /wp:gutenverse/post-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
