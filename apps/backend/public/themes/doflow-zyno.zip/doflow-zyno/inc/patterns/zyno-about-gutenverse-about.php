<?php
/**
 * Pattern: Zyno About Stats (DoFlow — fun-fact PRO rimosso)
 */
return array(
    'title'      => __( 'Zyno About Stats', 'doflow-zyno' ),
    'categories' => array( 'zyno-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1200"},"gap":"no","elementId":"guten-zabout1","background":{"type":"default","color":{"type":"variable","id":"theme-0"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"80","bottom":"80"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="zabout1"><section class="wp-block-gutenverse-section guten-element guten-section guten-zabout1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-zab-left","padding":{"Desktop":{"unit":"px","dimension":{"right":"60"}},"Tablet":{"unit":"px","dimension":{"right":"0","bottom":"40"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zab-left"><div class="guten-column-wrapper" data-id="zab-left">
<!-- wp:gutenverse/advanced-heading {"elementId":"guten-zab-h","alignText":{"Desktop":"left"},"text":"{{about_heading}} ","focusText":"{{about_focus}}","showSub":"none","showLine":"none","mainColor":{"r":255,"g":255,"b":255,"a":1},"mainTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"42"},"Tablet":{"unit":"px","point":"32"}},"weight":"700","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusColor":{"type":"variable","id":"theme-2"},"focusTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"42"}},"weight":"700"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}}}} -->
<div class="guten-element guten-advanced-heading guten-zab-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{about_heading}} </span><span class="heading-focus">{{about_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"16px","lineHeight":"1.7"},"spacing":{"margin":{"bottom":"32px"}}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:16px;line-height:1.7;margin-bottom:32px;">{{about_description}}</p><!-- /wp:paragraph -->
<!-- wp:gutenverse/button {"elementId":"guten-zabtn","content":"{{about_cta}}","paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"16","bottom":"16","right":"32","left":"32"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-1"}},"buttonBackgroundHover":{"type":"default","color":{"r":255,"g":255,"b":255,"a":1}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"50","right":"50","bottom":"50","left":"50"}}}},"color":{"r":255,"g":255,"b":255,"a":1},"hoverTextColor":{"type":"variable","id":"theme-0"},"typography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"15"}},"weight":"600"}} -->
<div class="guten-element guten-button-wrapper guten-zabtn"><a class="guten-button guten-button-sm" href="mailto:{{contact_email}}"><span>{{about_cta}}</span></a></div>
<!-- /wp:gutenverse/button -->
</div></div><!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-zab-right","padding":{"Desktop":{"unit":"px","dimension":{"left":"40"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zab-right"><div class="guten-column-wrapper" data-id="zab-right">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
<!-- wp:group {"style":{"color":{"background":"#0a2a6e"},"border":{"radius":"16px"},"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group has-background" style="background-color:#0a2a6e;border-radius:16px;padding:28px;">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"44px","fontWeight":"800"}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:44px;font-weight:800;">{{stat1_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"14px"}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:14px;">{{stat1_label}}</p><!-- /wp:paragraph -->
</div><!-- /wp:group -->
<!-- wp:group {"style":{"color":{"background":"#0a2a6e"},"border":{"radius":"16px"},"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group has-background" style="background-color:#0a2a6e;border-radius:16px;padding:28px;">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"44px","fontWeight":"800"}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:44px;font-weight:800;">{{stat2_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"14px"}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:14px;">{{stat2_label}}</p><!-- /wp:paragraph -->
</div><!-- /wp:group -->
<!-- wp:group {"style":{"color":{"background":"#0a2a6e"},"border":{"radius":"16px"},"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group has-background" style="background-color:#0a2a6e;border-radius:16px;padding:28px;">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"44px","fontWeight":"800"}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:44px;font-weight:800;">{{stat3_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"14px"}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:14px;">{{stat3_label}}</p><!-- /wp:paragraph -->
</div><!-- /wp:group -->
<!-- wp:group {"style":{"color":{"background":"#0a2a6e"},"border":{"radius":"16px"},"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"}}},"layout":{"type":"constrained"}} --><div class="wp-block-group has-background" style="background-color:#0a2a6e;border-radius:16px;padding:28px;">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"44px","fontWeight":"800"}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:44px;font-weight:800;">{{stat4_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#c8e4ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"14px"}}} --><p class="has-text-color" style="color:#c8e4ff;font-family:Plus Jakarta Sans;font-size:14px;">{{stat4_label}}</p><!-- /wp:paragraph -->
</div><!-- /wp:group -->
</div>
</div></div><!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
