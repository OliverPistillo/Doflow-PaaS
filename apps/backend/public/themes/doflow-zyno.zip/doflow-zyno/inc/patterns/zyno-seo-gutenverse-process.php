<?php
/**
 * Pattern: Zyno SEO Process — 3 steps (DoFlow — icon-box PRO rimosso)
 */
return array(
    'title'      => __( 'Zyno SEO Process', 'doflow-zyno' ),
    'categories' => array( 'zyno-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1200"},"gap":"no","elementId":"guten-zproc1","background":{"type":"default","color":{"type":"variable","id":"theme-3"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"90","bottom":"90"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="zproc1"><section class="wp-block-gutenverse-section guten-element guten-section guten-zproc1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-zproc-head","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"56"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zproc-head"><div class="guten-column-wrapper" data-id="zproc-head">
<!-- wp:gutenverse/advanced-heading {"elementId":"guten-zproc-h","alignText":{"Desktop":"center"},"text":"{{process_heading}} ","focusText":"{{process_focus}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"theme-0"},"mainTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"40"},"Tablet":{"unit":"px","point":"32"}},"weight":"700","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusColor":{"type":"variable","id":"theme-1"},"focusTypography":{"font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"unit":"px","point":"40"}},"weight":"700"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"16"}}}} -->
<div class="guten-element guten-advanced-heading guten-zproc-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{process_heading}} </span><span class="heading-focus">{{process_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"16px","lineHeight":"1.7"}}} --><p class="has-text-align-center has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:16px;line-height:1.7;">{{process_description}}</p><!-- /wp:paragraph -->
</div></div><!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-zp1","padding":{"Desktop":{"unit":"px","dimension":{"top":"36","right":"32","bottom":"36","left":"32"}}},"background":{"type":"default","color":{"r":255,"g":255,"b":255,"a":1}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"16","right":"16","bottom":"16","left":"16"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zp1"><div class="guten-column-wrapper" data-id="zp1">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"48px","fontWeight":"800"},"spacing":{"margin":{"bottom":"16px"}}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:48px;font-weight:800;margin-bottom:16px;">01</h2><!-- /wp:heading -->
<!-- wp:heading {"level":3,"style":{"color":{"text":"#001f4f"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"20px","fontWeight":"700"},"spacing":{"margin":{"bottom":"12px"}}}} --><h3 class="wp-block-heading has-text-color" style="color:#001f4f;font-family:Plus Jakarta Sans;font-size:20px;font-weight:700;margin-bottom:12px;">{{step1_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;">{{step1_desc}}</p><!-- /wp:paragraph -->
</div></div><!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-zp2","padding":{"Desktop":{"unit":"px","dimension":{"top":"36","right":"32","bottom":"36","left":"32"}}},"background":{"type":"default","color":{"r":255,"g":255,"b":255,"a":1}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"16","right":"16","bottom":"16","left":"16"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zp2"><div class="guten-column-wrapper" data-id="zp2">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"48px","fontWeight":"800"},"spacing":{"margin":{"bottom":"16px"}}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:48px;font-weight:800;margin-bottom:16px;">02</h2><!-- /wp:heading -->
<!-- wp:heading {"level":3,"style":{"color":{"text":"#001f4f"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"20px","fontWeight":"700"},"spacing":{"margin":{"bottom":"12px"}}}} --><h3 class="wp-block-heading has-text-color" style="color:#001f4f;font-family:Plus Jakarta Sans;font-size:20px;font-weight:700;margin-bottom:12px;">{{step2_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;">{{step2_desc}}</p><!-- /wp:paragraph -->
</div></div><!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-zp3","padding":{"Desktop":{"unit":"px","dimension":{"top":"36","right":"32","bottom":"36","left":"32"}}},"background":{"type":"default","color":{"r":255,"g":255,"b":255,"a":1}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"16","right":"16","bottom":"16","left":"16"}}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-zp3"><div class="guten-column-wrapper" data-id="zp3">
<!-- wp:heading {"level":2,"style":{"color":{"text":"#0047ff"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"48px","fontWeight":"800"},"spacing":{"margin":{"bottom":"16px"}}}} --><h2 class="wp-block-heading has-text-color" style="color:#0047ff;font-family:Plus Jakarta Sans;font-size:48px;font-weight:800;margin-bottom:16px;">03</h2><!-- /wp:heading -->
<!-- wp:heading {"level":3,"style":{"color":{"text":"#001f4f"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"20px","fontWeight":"700"},"spacing":{"margin":{"bottom":"12px"}}}} --><h3 class="wp-block-heading has-text-color" style="color:#001f4f;font-family:Plus Jakarta Sans;font-size:20px;font-weight:700;margin-bottom:12px;">{{step3_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#667995"},"typography":{"fontFamily":"Plus Jakarta Sans","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#667995;font-family:Plus Jakarta Sans;font-size:15px;line-height:1.7;">{{step3_desc}}</p><!-- /wp:paragraph -->
</div></div><!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
