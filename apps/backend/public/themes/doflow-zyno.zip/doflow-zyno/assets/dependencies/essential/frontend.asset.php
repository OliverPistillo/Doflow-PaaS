<?php return array('dependencies' => array(), 'version' => 'e5dc38b9f3a4bf39f77a');
