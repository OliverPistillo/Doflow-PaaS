<?php return array('dependencies' => array(), 'version' => 'e2cb8663d745c23e3727');
