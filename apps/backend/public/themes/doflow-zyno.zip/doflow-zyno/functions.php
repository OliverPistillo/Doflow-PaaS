<?php
/**
 * Theme Functions
 *
 * @author Jegstudio
 * @package zyno
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

defined( 'ZYNO_VERSION' ) || define( 'ZYNO_VERSION', '1.0.3' );
defined( 'ZYNO_DIR' ) || define( 'ZYNO_DIR', trailingslashit( get_template_directory() ) );

defined( 'GUTENVERSE_COMPANION_REQUIRED_VERSION' ) || define( 'GUTENVERSE_COMPANION_REQUIRED_VERSION', '2.0.2' );
defined( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION' ) || define( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION', '2.0.0' );

require get_parent_theme_file_path( 'inc/autoload.php' );

Zyno\Init::instance();
