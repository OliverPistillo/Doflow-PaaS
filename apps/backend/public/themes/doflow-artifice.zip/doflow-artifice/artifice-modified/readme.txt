=== Artifice ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4

== Description ==
Artifice delivers a sleek, modern design built for innovation—perfect for AI and Robotics companies. With its clean layout and professional structure, it helps you showcase expertise, inspire trust, and connect with researchers, institutions, and industry partners.

== Changelog ==

= Version 1.0.0 =
* Initial release