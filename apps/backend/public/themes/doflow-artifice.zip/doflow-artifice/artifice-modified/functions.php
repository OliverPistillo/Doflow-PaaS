<?php
/**
 * Theme Functions
 *
 * @author Jegtheme
 * @package artifice
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

defined( 'ARTIFICE_VERSION' ) || define( 'ARTIFICE_VERSION', '1.0.0' );
defined( 'ARTIFICE_DIR' ) || define( 'ARTIFICE_DIR', trailingslashit( get_template_directory() ) );

defined( 'GUTENVERSE_COMPANION_REQUIRED_VERSION' ) || define( 'GUTENVERSE_COMPANION_REQUIRED_VERSION', '1.0.5' );
defined( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION' ) || define( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION', '2.0.0' );

require get_parent_theme_file_path( 'inc/autoload.php' );

Artifice\Init::instance();
