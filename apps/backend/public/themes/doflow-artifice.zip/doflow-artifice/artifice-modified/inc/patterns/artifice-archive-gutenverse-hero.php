<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Artifice Archive Gutenverse Hero', 'artifice' ),
	'categories' => array( 'artifice-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1170"},"gap":"no","elementId":"guten-8ywGMo","background":{"type":"default","color":"","image":{"Desktop":{"id":536,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/female-engineer-man-working-at-industrial.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"},"blendMode":{"Desktop":"normal"}},"backgroundOverlay":{"type":"default","color":{"type":"variable","id":"gutenverse-background-primary"}},"opacity":"0.9","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"220","bottom":"140"}},"Tablet":{"unit":"px","dimension":{"top":"200","bottom":"120","right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"140","bottom":"60","right":"10","left":"10"}}},"zIndex":{"Desktop":0}} -->
<div class="section-wrapper" data-id="8ywGMo"><section class="wp-block-gutenverse-section guten-element guten-section guten-8ywGMo layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Mobile":null,"Tablet":100},"forceColumnHundred":{"Desktop":false,"previousValues":{"Tablet":"inherit"},"Tablet":false,"Mobile":false},"elementId":"guten-U7egHI","order":{"Desktop":"1","Mobile":1},"verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Desktop":{"unit":"px","dimension":{"left":"","bottom":""}},"Mobile":{"unit":"px","dimension":{"bottom":"","right":"","left":"","top":""}},"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"","left":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Tablet":{"unit":"px","dimension":{"top":"","right":"","left":"","bottom":""}}},"hideTablet":false,"hideMobile":false} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-U7egHI"><div class="guten-column-wrapper" data-id="U7egHI"><!-- wp:gutenverse/archive-title {"elementId":"guten-kMN2hp","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"BpZssO","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"48"},"Mobile":{"unit":"px","point":"28"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.3"}},"weight":"600","transform":"capitalize","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}},"color":{"type":"variable","id":"gutenverse-text-primary"}} -->
<div class="guten-element guten-archive-title guten-kMN2hp"></div>
<!-- /wp:gutenverse/archive-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
