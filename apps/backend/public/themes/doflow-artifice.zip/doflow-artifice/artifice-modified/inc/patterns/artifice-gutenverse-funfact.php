<?php
/**
 * Pattern: Artifice Funfact — 4 stats (DoFlow modified, no PRO blocks)
 */
return array(
    'title'      => __( 'Artifice Gutenverse Funfact', 'artifice' ),
    'categories' => array( 'artifice-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1270"},"gap":"no","elementId":"guten-facts1","background":{"type":"default","color":{"type":"variable","id":"gutenverse-background-primary"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"80","bottom":"80"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="facts1"><section class="wp-block-gutenverse-section guten-element guten-section guten-facts1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-facts-head","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"50"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-facts-head"><div class="guten-column-wrapper" data-id="facts-head">
<!-- wp:gutenverse/advanced-heading {"elementId":"guten-facts-h","alignText":{"Desktop":"center"},"text":"{{stats_heading}} ","focusText":"{{stats_focus}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"gutenverse-text-primary"},"mainTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"36"}},"weight":"600"},"focusColor":{"type":"variable","id":"gutenverse-secondary"},"focusTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"36"}},"weight":"600"}} -->
<div class="guten-element guten-advanced-heading guten-facts-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{stats_heading}} </span><span class="heading-focus">{{stats_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Tablet":50,"Mobile":100},"elementId":"guten-stat1","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-stat1"><div class="guten-column-wrapper" data-id="stat1">
<!-- wp:heading {"textAlign":"center","level":2,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"52px","fontWeight":"700"}}} --><h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:52px;font-weight:700;">{{stat1_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-align-center has-text-color" style="color:#ffffff;font-family:Inter;font-size:15px;">{{stat1_label}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Tablet":50,"Mobile":100},"elementId":"guten-stat2","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-stat2"><div class="guten-column-wrapper" data-id="stat2">
<!-- wp:heading {"textAlign":"center","level":2,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"52px","fontWeight":"700"}}} --><h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:52px;font-weight:700;">{{stat2_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-align-center has-text-color" style="color:#ffffff;font-family:Inter;font-size:15px;">{{stat2_label}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Tablet":50,"Mobile":100},"elementId":"guten-stat3","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-stat3"><div class="guten-column-wrapper" data-id="stat3">
<!-- wp:heading {"textAlign":"center","level":2,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"52px","fontWeight":"700"}}} --><h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:52px;font-weight:700;">{{stat3_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-align-center has-text-color" style="color:#ffffff;font-family:Inter;font-size:15px;">{{stat3_label}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Tablet":50,"Mobile":100},"elementId":"guten-stat4","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-stat4"><div class="guten-column-wrapper" data-id="stat4">
<!-- wp:heading {"textAlign":"center","level":2,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"52px","fontWeight":"700"}}} --><h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:52px;font-weight:700;">{{stat4_number}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-align-center has-text-color" style="color:#ffffff;font-family:Inter;font-size:15px;">{{stat4_label}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
