<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Artifice Single Gutenverse Hero', 'artifice' ),
	'categories' => array( 'artifice-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1170"},"gap":"no","elementId":"guten-8ywGMo","background":{"type":"default","color":"","image":{"Desktop":{"id":662,"image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/robot-ple.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"},"blendMode":{"Desktop":"normal"}},"backgroundOverlay":{"type":"default","color":{"type":"variable","id":"gutenverse-background-primary"}},"opacity":"0.9","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"220","bottom":"140"}},"Tablet":{"unit":"px","dimension":{"top":"200","bottom":"120","right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"140","bottom":"60","right":"10","left":"10"}}},"zIndex":{"Desktop":0}} -->
<div class="section-wrapper" data-id="8ywGMo"><section class="wp-block-gutenverse-section guten-element guten-section guten-8ywGMo layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Mobile":null,"Tablet":100},"forceColumnHundred":{"Desktop":false,"previousValues":{"Tablet":"inherit"},"Tablet":false,"Mobile":false},"elementId":"guten-U7egHI","order":{"Desktop":"1","Mobile":1},"verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Desktop":{"unit":"px","dimension":{"left":"","bottom":""}},"Mobile":{"unit":"px","dimension":{"bottom":"","right":"","left":"","top":""}},"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"","left":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Tablet":{"unit":"px","dimension":{"top":"","right":"","left":"","bottom":""}}},"hideTablet":false,"hideMobile":false} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-U7egHI"><div class="guten-column-wrapper" data-id="U7egHI"><!-- wp:gutenverse/post-title {"elementId":"guten-dQzIFq","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"BpZssO","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"48"},"Mobile":{"unit":"px","point":"28"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.3"}},"weight":"600","transform":"capitalize","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}},"color":{"type":"variable","id":"gutenverse-text-primary"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"40","top":"0"}},"Mobile":{"unit":"px","dimension":{"bottom":"20"}}}} -->
<div class="guten-element guten-post-title guten-dQzIFq"></div>
<!-- /wp:gutenverse/post-title -->

<!-- wp:gutenverse/wrapper {"elementId":"guten-YuhqnU","displayType":"flex","displayWidth":{"Desktop":{"unit":"%","point":"50"},"Mobile":{"unit":"%","point":"100"}},"horizontalAlign":{"Desktop":"center","Tablet":false,"Mobile":false},"verticalAlign":{"Desktop":"center","Tablet":false,"Mobile":false}} -->
<div class="guten-element guten-wrap-helper no-margin guten-YuhqnU flex"><div class="guten-inner-wrap" data-id="YuhqnU"><!-- wp:gutenverse/post-terms {"elementId":"guten-Mlu2AN","linkTo":"term","typography":{"type":"variable","id":"EGipIP","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.3"},"Tablet":{"unit":"px"},"Mobile":{"unit":"px"}},"weight":"500","transform":"normal","decoration":"none","style":"normal"},"color":{"type":"variable","id":"gutenverse-secondary"},"margin":{"Desktop":{"unit":"px","dimension":{"right":""}},"Mobile":{"unit":"px","dimension":{"right":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-terms guten-Mlu2AN"></div>
<!-- /wp:gutenverse/post-terms -->

<!-- wp:gutenverse/icon {"elementId":"guten-4zy2LD","icon":"fas fa-circle","iconColorOne":{"type":"variable","id":"gutenverse-gz-3-msh"},"iconSize":{"Desktop":{"unit":"px","point":"8"},"Mobile":{"unit":"px","point":"6"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"gutenverse-primary"},"animation":{"type":{"Desktop":"none"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-2","right":"20","bottom":"","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"-3","right":"10","bottom":"0","left":"10"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-4zy2LD guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-circle"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-date {"elementId":"guten-ubJvTg","typography":{"type":"variable","id":"EGipIP","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.3"},"Tablet":{"unit":"px"},"Mobile":{"unit":"px"}},"weight":"500","transform":"normal","decoration":"none","style":"normal"},"color":{"type":"variable","id":"gutenverse-text-secondary"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"-2","top":"2"}},"Mobile":{"unit":"px","dimension":{"top":"2","right":"0","bottom":"-2","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-ubJvTg"></div>
<!-- /wp:gutenverse/post-date --></div></div>
<!-- /wp:gutenverse/wrapper --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
