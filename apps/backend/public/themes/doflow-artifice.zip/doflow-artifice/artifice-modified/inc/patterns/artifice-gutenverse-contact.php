<?php
/**
 * Pattern: Artifice Contact (DoFlow — nuovo pattern per pagina Contact)
 */
return array(
    'title'      => __( 'Artifice Gutenverse Contact', 'artifice' ),
    'categories' => array( 'artifice-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1270"},"gap":"no","elementId":"guten-contact1","background":{"type":"default","color":{"type":"variable","id":"gutenverse-background-primary"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"100","bottom":"100"}},"Tablet":{"unit":"px","dimension":{"top":"70","right":"20","bottom":"70","left":"20"}}}} -->
<div class="section-wrapper" data-id="contact1"><section class="wp-block-gutenverse-section guten-element guten-section guten-contact1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":55,"Tablet":100},"elementId":"guten-cont-left","padding":{"Desktop":{"unit":"px","dimension":{"right":"60"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-cont-left"><div class="guten-column-wrapper" data-id="cont-left">

<!-- wp:gutenverse/advanced-heading {"elementId":"guten-cont-h","alignText":{"Desktop":"left"},"text":"{{contact_heading}} ","focusText":"{{contact_focus}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"gutenverse-text-primary"},"mainTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"40"},"Tablet":{"unit":"px","point":"32"}},"weight":"600","lineHeight":{"Desktop":{"unit":"em","point":"1.3"}}},"focusColor":{"type":"variable","id":"gutenverse-secondary"},"focusTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"40"}},"weight":"600"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"24"}}}} -->
<div class="guten-element guten-advanced-heading guten-cont-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{contact_heading}} </span><span class="heading-focus">{{contact_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-cont-p","alignment":{"Desktop":"left"},"textColor":{"type":"variable","id":"gutenverse-text-secondary"},"typography":{"font":{"label":"Inter","value":"Inter","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.7"}}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"40"}}}} -->
<div class="guten-element gutenverse-text-editor guten-cont-p"><div class="text-content-inner"><!-- wp:paragraph --><p>{{contact_description}}</p><!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/button {"elementId":"guten-cont-btn","content":"{{contact_cta}}","paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"18","bottom":"18","right":"36","left":"36"}}},"buttonBackground":{"type":"default","color":{"r":0,"g":0,"b":0,"a":0}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"gutenverse-secondary"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"50","right":"50","bottom":"50","left":"50"}}},"all":{"type":"solid","width":1,"color":{"type":"variable","id":"gutenverse-accent"}}},"color":{"type":"variable","id":"gutenverse-text-primary"},"typography":{"font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"15"}},"weight":"500","transform":"capitalize"},"hoverTextColor":{"type":"variable","id":"gutenverse-5-qk-3-gr"}} -->
<div class="guten-element guten-button-wrapper guten-cont-btn"><a class="guten-button guten-button-sm" href="mailto:{{contact_email}}"><span>{{contact_cta}}</span></a></div>
<!-- /wp:gutenverse/button -->

</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":45,"Tablet":100},"elementId":"guten-cont-right","padding":{"Desktop":{"unit":"px","dimension":{"top":"10","left":"40"}},"Tablet":{"unit":"px","dimension":{"top":"50","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-cont-right"><div class="guten-column-wrapper" data-id="cont-right">

<!-- wp:heading {"level":4,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"13px","fontWeight":"600","letterSpacing":"0.12em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"8px"}}}} --><h4 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:13px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:8px;">Email</h4><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"16px"},"spacing":{"margin":{"bottom":"32px"}}}} --><p class="has-text-color" style="color:#ffffff;font-family:Inter;font-size:16px;margin-bottom:32px;"><a href="mailto:{{contact_email}}" style="color:#ffffff;text-decoration:none;">{{contact_email}}</a></p><!-- /wp:paragraph -->

<!-- wp:heading {"level":4,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"13px","fontWeight":"600","letterSpacing":"0.12em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"8px"}}}} --><h4 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:13px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:8px;">Telefono</h4><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff"},"typography":{"fontFamily":"Inter","fontSize":"16px"},"spacing":{"margin":{"bottom":"32px"}}}} --><p class="has-text-color" style="color:#ffffff;font-family:Inter;font-size:16px;margin-bottom:32px;">{{contact_phone}}</p><!-- /wp:paragraph -->

<!-- wp:heading {"level":4,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"13px","fontWeight":"600","letterSpacing":"0.12em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"8px"}}}} --><h4 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:13px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:8px;">Indirizzo</h4><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff73"},"typography":{"fontFamily":"Inter","fontSize":"16px"}}} --><p class="has-text-color" style="color:#ffffff73;font-family:Inter;font-size:16px;">{{contact_address}}</p><!-- /wp:paragraph -->

</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
