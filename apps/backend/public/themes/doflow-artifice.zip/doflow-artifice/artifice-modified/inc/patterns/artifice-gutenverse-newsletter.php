<?php
/**
 * Pattern: Artifice Newsletter/Contact CTA (DoFlow modified, no PRO form-builder)
 */
return array(
    'title'      => __( 'Artifice Gutenverse Newsletter', 'artifice' ),
    'categories' => array( 'artifice-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1270"},"gap":"no","elementId":"guten-news1","background":{"type":"default","color":{"type":"variable","id":"gutenverse-background-secondary"}},"backgroundOverlay":{"type":"gradient","gradientColor":[{"color":"rgba(46,218,241,1)","active":false,"opacity":1,"id":1,"offset":"0.000"},{"color":"rgba(2,20,32,1)","active":true,"opacity":1,"id":2,"offset":"0.929"}],"gradientType":"radial","gradientRadial":"center center"},"opacity":"0.15","padding":{"Desktop":{"unit":"px","dimension":{"top":"80","bottom":"80"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="news1"><section class="wp-block-gutenverse-section guten-element guten-section guten-news1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-news-col","horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-news-col"><div class="guten-column-wrapper" data-id="news-col">

<!-- wp:gutenverse/advanced-heading {"elementId":"guten-news-h","alignText":{"Desktop":"center"},"text":"{{newsletter_heading}} ","focusText":"{{newsletter_focus}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"gutenverse-text-primary"},"mainTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"}},"weight":"600"},"focusColor":{"type":"variable","id":"gutenverse-secondary"},"focusTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"}},"weight":"600"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}}}} -->
<div class="guten-element guten-advanced-heading guten-news-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{newsletter_heading}} </span><span class="heading-focus">{{newsletter_focus}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-news-p","alignment":{"Desktop":"center"},"textColor":{"type":"variable","id":"gutenverse-text-secondary"},"typography":{"type":"variable","id":"text","font":{"label":"Inter","value":"Inter","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.6"}}},"positioningType":{"Desktop":"custom"},"positioningWidth":{"Desktop":{"unit":"px","point":"580"}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"36"}}}} -->
<div class="guten-element gutenverse-text-editor guten-news-p"><div class="text-content-inner"><!-- wp:paragraph --><p>{{newsletter_text}}</p><!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/button {"elementId":"guten-news-btn","content":"{{newsletter_cta}}","paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"18","bottom":"18","right":"40","left":"40"}}},"buttonBackground":{"type":"default","color":{"r":0,"g":0,"b":0,"a":0}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"gutenverse-secondary"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"50","right":"50","bottom":"50","left":"50"}}},"all":{"type":"solid","width":1,"color":{"type":"variable","id":"gutenverse-accent"}}},"color":{"type":"variable","id":"gutenverse-text-primary"},"typography":{"type":"variable","id":"button-primary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"15"}},"weight":"500","transform":"capitalize"},"hoverTextColor":{"type":"variable","id":"gutenverse-5-qk-3-gr"}} -->
<div class="guten-element guten-button-wrapper guten-news-btn"><a class="guten-button guten-button-sm" href="mailto:{{contact_email}}"><span>{{newsletter_cta}}</span></a></div>
<!-- /wp:gutenverse/button -->

</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
