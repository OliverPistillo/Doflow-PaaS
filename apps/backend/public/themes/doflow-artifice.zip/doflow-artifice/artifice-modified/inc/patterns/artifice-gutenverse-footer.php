<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Artifice Gutenverse Footer', 'artifice' ),
	'categories' => array( 'artifice-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1290"},"elementId":"guten-HmGAmQ","padding":{"Desktop":{"unit":"px","dimension":{"top":"60","bottom":"15"}},"Tablet":{"unit":"px","dimension":{"top":"40","bottom":"20","right":"20","left":"20"}},"Mobile":{"unit":"px","dimension":{"top":"40"}}}} -->
<div class="section-wrapper" data-id="HmGAmQ"><section class="wp-block-gutenverse-section guten-element guten-section guten-HmGAmQ layout-boxed align-stretch"><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-CXkVXX"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-CXkVXX"><div class="guten-column-wrapper" data-id="CXkVXX"><!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-jtbkEA","margin":{"Desktop":{"unit":"px","dimension":{"bottom":"50"}}},"hideTablet":true,"hideMobile":true} -->
<div class="section-wrapper" data-id="jtbkEA"><section class="wp-block-gutenverse-section guten-element guten-section guten-jtbkEA hide-tablet hide-mobile layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":30.1,"Tablet":"100"},"elementId":"guten-WLUBdI","verticalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-WLUBdI"><div class="guten-column-wrapper" data-id="WLUBdI"><!-- wp:gutenverse/icon-list {"elementId":"guten-9p2p3i","displayInline":true,"spaceBetween":{"Desktop":"36"},"alignList":{"Desktop":"flex-start"},"verticalAlign":"center","iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"gutenverse-text-primary"},"textColorHover":{"type":"variable","id":"gutenverse-secondary"},"textIndent":{"Desktop":"0"},"textTypography":{"type":"variable","id":"MtO2hH","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.2"}},"weight":"500","transform":"normal","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}}} -->
<div class="guten-element guten-icon-list guten-9p2p3i"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-iHDP0i","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-iHDP0i"><div class="list-divider"></div><a id="guten-iHDP0i" href="#"><i class="fas fa-check"></i><span class="list-text ">Home</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-AG5Fsm","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-AG5Fsm"><div class="list-divider"></div><a id="guten-AG5Fsm" href="#"><i class="fas fa-check"></i><span class="list-text ">Services</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-y824fT","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-y824fT"><div class="list-divider"></div><a id="guten-y824fT" href="#"><i class="fas fa-check"></i><span class="list-text ">Projects</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-njsTS8","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-njsTS8"><div class="list-divider"></div><a id="guten-njsTS8" href="#"><i class="fas fa-check"></i><span class="list-text ">Contact</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":39.9,"Tablet":"100"},"elementId":"guten-EALyAs","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-EALyAs"><div class="guten-column-wrapper" data-id="EALyAs"><!-- wp:gutenverse/image {"elementId":"guten-1s8qe5","imgSrc":{"media":{"imageId":6,"sizes":{"thumbnail":{"height":150,"width":150,"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","orientation":"landscape"},"medium":{"height":71,"width":300,"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","orientation":"landscape"},"full":{"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","height":188,"width":800,"orientation":"landscape"}}},"size":"full"},"altType":"original","altOriginal":"","captionOriginal":"","width":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"100"},"Mobile":{"point":"","unit":"px"}},"height":{"Tablet":{"unit":"px"}},"url":"#","imgBorder":{"radius":{"Desktop":[]}},"imgBorderResponsive":{"Tablet":{"radius":[]},"Mobile":{"radius":[]}},"align":{"Desktop":"left"},"positioningType":{"Desktop":"custom","Tablet":"custom","Mobile":"custom"},"positioningWidth":{"Desktop":{"unit":"%","point":"36"},"Tablet":{"unit":"%","point":"60"},"Mobile":{"unit":"%","point":"90"}}} -->
<div class="wp-block-gutenverse-image guten-element guten-image guten-1s8qe5"><a class="guten-image-wrapper" href="#"><img class="gutenverse-image-box-filled" src="https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp" height="188" width="800" alt=""/></a></div>
<!-- /wp:gutenverse/image --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":30,"Tablet":"100"},"elementId":"guten-z50eqE","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"flex-end"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-z50eqE"><div class="guten-column-wrapper" data-id="z50eqE"><!-- wp:gutenverse/icon-list {"elementId":"guten-vCFveo","displayInline":true,"spaceBetween":{"Desktop":"36"},"alignList":{"Desktop":"flex-end"},"verticalAlign":"center","iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"gutenverse-text-primary"},"textColorHover":{"type":"variable","id":"gutenverse-secondary"},"textIndent":{"Desktop":"0"},"textTypography":{"type":"variable","id":"MtO2hH","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.2"}},"weight":"500","transform":"normal","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}}} -->
<div class="guten-element guten-icon-list guten-vCFveo"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-ouh9tF","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-ouh9tF"><div class="list-divider"></div><a id="guten-ouh9tF" href="#"><i class="fas fa-check"></i><span class="list-text ">Privacy &amp; Policy</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-IK6Di2","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-IK6Di2"><div class="list-divider"></div><a id="guten-IK6Di2" href="#"><i class="fas fa-check"></i><span class="list-text ">Terms Condition</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->

<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-KSBWXi","margin":{"Desktop":{"unit":"px","dimension":{"bottom":"50"}}},"hideDesktop":true} -->
<div class="section-wrapper" data-id="KSBWXi"><section class="wp-block-gutenverse-section guten-element guten-section guten-KSBWXi hide-desktop layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":30.1,"Tablet":100},"elementId":"guten-GeNgBy","order":{"Desktop":"1","Tablet":2},"verticalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-GeNgBy"><div class="guten-column-wrapper" data-id="GeNgBy"><!-- wp:gutenverse/icon-list {"elementId":"guten-FbDVSw","displayInline":true,"spaceBetween":{"Desktop":"36","Mobile":"12"},"alignList":{"Desktop":"flex-start","Tablet":"center","Mobile":"center"},"verticalAlign":"center","iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"gutenverse-text-primary"},"textColorHover":{"type":"variable","id":"gutenverse-secondary"},"textIndent":{"Desktop":"0"},"textTypography":{"type":"variable","id":"MtO2hH","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.2"}},"weight":"500","transform":"normal","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}},"margin":{"Tablet":{"unit":"px","dimension":{"bottom":"24"}}}} -->
<div class="guten-element guten-icon-list guten-FbDVSw"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-vXBb1g","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-vXBb1g"><div class="list-divider"></div><a id="guten-vXBb1g" href="#"><i class="fas fa-check"></i><span class="list-text ">Home</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-mGPOsI","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-mGPOsI"><div class="list-divider"></div><a id="guten-mGPOsI" href="#"><i class="fas fa-check"></i><span class="list-text ">Services</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-v6PFhg","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-v6PFhg"><div class="list-divider"></div><a id="guten-v6PFhg" href="#"><i class="fas fa-check"></i><span class="list-text ">Projects</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-UwgOti","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-UwgOti"><div class="list-divider"></div><a id="guten-UwgOti" href="#"><i class="fas fa-check"></i><span class="list-text ">Contact</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":39.9,"Tablet":100},"elementId":"guten-xSbmKd","order":{"Desktop":"1","Tablet":1},"verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center"},"margin":{"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-xSbmKd"><div class="guten-column-wrapper" data-id="xSbmKd"><!-- wp:gutenverse/image {"elementId":"guten-oSELbG","imgSrc":{"media":{"imageId":6,"sizes":{"thumbnail":{"height":150,"width":150,"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","orientation":"landscape"},"medium":{"height":71,"width":300,"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","orientation":"landscape"},"full":{"url":"https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp","height":188,"width":800,"orientation":"landscape"}}},"size":"full"},"altType":"original","altOriginal":"","captionOriginal":"","width":{"Desktop":{"unit":"%","point":""},"Tablet":{"unit":"%","point":"32"},"Mobile":{"point":"60","unit":"%"}},"imgBorder":{"radius":{"Desktop":[]}},"imgBorderResponsive":{"Tablet":{"radius":[]},"Mobile":{"radius":[]}},"align":{"Desktop":"left","Tablet":"center"},"margin":{"Tablet":{"unit":"px","dimension":{"bottom":"25"}}},"positioningType":{"Desktop":"custom","Tablet":"custom","Mobile":"custom"},"positioningWidth":{"Desktop":{"unit":"%","point":"36"},"Tablet":{"unit":"%","point":"60"},"Mobile":{"unit":"%","point":"90"}}} -->
<div class="wp-block-gutenverse-image guten-element guten-image guten-oSELbG"><div class="guten-image-wrapper"><img class="gutenverse-image-box-filled" src="https://designer.gutenverse.com/artifice/wp-content/uploads/sites/247/2025/08/logo-artifice.webp" height="188" width="800" alt=""/></div></div>
<!-- /wp:gutenverse/image --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":30,"Tablet":100},"elementId":"guten-qhlpol","order":{"Desktop":"1","Tablet":3},"verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"flex-end"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-qhlpol"><div class="guten-column-wrapper" data-id="qhlpol"><!-- wp:gutenverse/icon-list {"elementId":"guten-jM7FPv","displayInline":true,"spaceBetween":{"Desktop":"36","Mobile":"12"},"alignList":{"Desktop":"flex-end","Tablet":"center"},"verticalAlign":"center","iconSize":{"Desktop":"0"},"textColor":{"type":"variable","id":"gutenverse-text-primary"},"textColorHover":{"type":"variable","id":"gutenverse-secondary"},"textIndent":{"Desktop":"0"},"textTypography":{"type":"variable","id":"MtO2hH","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.2"}},"weight":"500","transform":"normal","decoration":"none","style":"normal","spacing":{"Desktop":"0.02"}}} -->
<div class="guten-element guten-icon-list guten-jM7FPv"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-ZYxsUp","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-ZYxsUp"><div class="list-divider"></div><a id="guten-ZYxsUp" href="#"><i class="fas fa-check"></i><span class="list-text ">Privacy &amp; Policy</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-u4ij57","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-u4ij57"><div class="list-divider"></div><a id="guten-u4ij57" href="#"><i class="fas fa-check"></i><span class="list-text ">Terms Condition</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->

<!-- wp:gutenverse/section {"width":{"Desktop":"1290"},"gap":"no","elementId":"guten-20oi2i","border":{"top":{"type":"solid","width":1,"color":{"r":255,"g":255,"b":255,"a":0.08}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"30"}}}} -->
<div class="section-wrapper" data-id="20oi2i"><section class="wp-block-gutenverse-section guten-element guten-section guten-20oi2i layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":"100"},"elementId":"guten-V8oEUn","verticalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-V8oEUn"><div class="guten-column-wrapper" data-id="V8oEUn"><!-- wp:gutenverse/text-editor {"elementId":"guten-lyUnu6","alignment":{"Tablet":"center"},"textColor":{"type":"variable","id":"gutenverse-text-secondary"},"typography":{"type":"variable","id":"text-small","font":{"label":"Inter","value":"Inter","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"}},"weight":"300","transform":"normal","decoration":"none","style":"normal"},"containsAnchorTag":true,"linkColor":{"type":"variable","id":"gutenverse-text-primary"},"linkTypography":{"font":{"label":"Inter","value":"Inter","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"}},"weight":"400","transform":"normal","decoration":"none","style":"normal"},"linkColorHover":{"type":"variable","id":"gutenverse-secondary"},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":[],"Tablet":{"unit":"px","dimension":{"bottom":"20"}},"Mobile":{"unit":"px","dimension":{"bottom":"20"}}},"padding":{"Desktop":[],"Tablet":[],"Mobile":[]}} -->
<div class="guten-element gutenverse-text-editor guten-lyUnu6"><div class="text-content-inner"><!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"},":hover":{"color":{"text":"var:preset|color|a57TTR"}}}}}} -->
<p class="has-link-color">AI &amp; Robotics WordPress Theme Powered by <a href="https://gutenverse.com/" target="_blank" rel="noreferrer noopener">Gutenverse Blocks Addons</a>.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":100},"elementId":"guten-IMuiTA","horizontalAlign":{"Desktop":"flex-end","Tablet":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-IMuiTA"><div class="guten-column-wrapper" data-id="IMuiTA"><!-- wp:gutenverse/social-icons {"elementId":"guten-E8Ouhx","iconSize":{"Desktop":{"point":"14","unit":"px"},"Mobile":{"point":"12","unit":"px"}},"gap":{"Desktop":"15"},"alignment":{"Desktop":"flex-end","Tablet":"center"},"shape":"circle","iconColor":{"type":"variable","id":"gutenverse-primary"},"bgColor":{"r":255,"g":255,"b":255,"a":0},"iconBorder":{"all":{"type":"solid","width":1,"color":{"type":"variable","id":"gutenverse-secondary"}}},"itemPadding":{"Desktop":{"unit":"px","dimension":{"top":"10","right":"10","bottom":"10","left":"10"}},"Mobile":{"unit":"px","dimension":{"top":"10","right":"10","bottom":"10","left":"10"}},"Tablet":{"unit":"px","dimension":{"top":"12","right":"12","bottom":"12","left":"12"}}},"hoverIconColor":{"type":"variable","id":"gutenverse-background-primary"},"hoverBgColor":{"type":"variable","id":"gutenverse-secondary"},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-social-icons guten-E8Ouhx circle horizontal fill"><!-- wp:gutenverse/social-icon {"elementId":"guten-ptOat5"} -->
<div class="guten-element guten-social-icon guten-ptOat5 facebook"><a id="guten-ptOat5" href="#"><i class="gtn gtn-facebook-light"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-ARU5PL"} -->
<div class="guten-element guten-social-icon guten-ARU5PL twitter"><a id="guten-ARU5PL" href="#"><i class="fab fa-x-twitter"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-i8DyqE"} -->
<div class="guten-element guten-social-icon guten-i8DyqE instagram"><a id="guten-i8DyqE" href="#"><i class="fab fa-instagram"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-YwsBeW"} -->
<div class="guten-element guten-social-icon guten-YwsBeW youtube"><a id="guten-YwsBeW" href="#"><i class="gtn gtn-youtube-v-light"></i></a></div>
<!-- /wp:gutenverse/social-icon --></div>
<!-- /wp:gutenverse/social-icons --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '[{"name":"logo-artifice.webp","image_url":"https:\/\/designer.gutenverse.com\/artifice\/wp-content\/uploads\/sites\/247\/2025\/08\/logo-artifice.webp","type":"sync","id":404,"image_id":6}]',
	'is_sync' => true,
);
