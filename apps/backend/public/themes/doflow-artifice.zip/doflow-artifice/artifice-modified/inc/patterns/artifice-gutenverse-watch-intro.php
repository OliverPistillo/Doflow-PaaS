<?php
/**
 * Pattern: Artifice Watch Intro — 3 feature columns (DoFlow modified, no PRO blocks)
 */
return array(
    'title'      => __( 'Artifice Gutenverse Watch Intro', 'artifice' ),
    'categories' => array( 'artifice-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1270"},"gap":"no","elementId":"guten-wintro1","background":{"type":"default","color":{"type":"variable","id":"gutenverse-background-secondary"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"80","bottom":"80"}},"Tablet":{"unit":"px","dimension":{"top":"60","right":"20","bottom":"60","left":"20"}}}} -->
<div class="section-wrapper" data-id="wintro1"><section class="wp-block-gutenverse-section guten-element guten-section guten-wintro1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-wintro-head","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"50"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wintro-head"><div class="guten-column-wrapper" data-id="wintro-head">
<!-- wp:gutenverse/advanced-heading {"elementId":"guten-wintro-h","alignText":{"Desktop":"center"},"text":"{{about_heading}} ","focusText":"{{company_name}}","showSub":"none","showLine":"none","mainColor":{"type":"variable","id":"gutenverse-text-primary"},"mainTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"}},"weight":"600"},"focusColor":{"type":"variable","id":"gutenverse-secondary"},"focusTypography":{"type":"variable","id":"secondary","font":{"label":"Orbitron","value":"Orbitron","type":"google"},"size":{"Desktop":{"unit":"px","point":"38"}},"weight":"600"}} -->
<div class="guten-element guten-advanced-heading guten-wintro-h"><div class="heading-section"><h2 class="heading-title"><span class="heading-title">{{about_heading}} </span><span class="heading-focus">{{company_name}}</span></h2></div></div>
<!-- /wp:gutenverse/advanced-heading -->
<!-- wp:gutenverse/text-editor {"elementId":"guten-wintro-sub","alignment":{"Desktop":"center"},"textColor":{"type":"variable","id":"gutenverse-text-secondary"},"typography":{"type":"variable","id":"text","font":{"label":"Inter","value":"Inter","type":"google"},"size":{"Desktop":{"unit":"px","point":"17"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.6"}}},"positioningType":{"Desktop":"custom"},"positioningWidth":{"Desktop":{"unit":"px","point":"640"}}} -->
<div class="guten-element gutenverse-text-editor guten-wintro-sub"><div class="text-content-inner"><!-- wp:paragraph --><p>{{about_description}}</p><!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf1","padding":{"Desktop":{"unit":"px","dimension":{"top":"30","right":"30","bottom":"30","left":"30"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf1"><div class="guten-column-wrapper" data-id="wf1">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"22px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:22px;font-weight:600;">{{feature1_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff73"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-color" style="color:#ffffff73;font-family:Inter;font-size:15px;">{{feature1_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf2","padding":{"Desktop":{"unit":"px","dimension":{"top":"30","right":"30","bottom":"30","left":"30"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf2"><div class="guten-column-wrapper" data-id="wf2">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"22px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:22px;font-weight:600;">{{feature2_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff73"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-color" style="color:#ffffff73;font-family:Inter;font-size:15px;">{{feature2_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf3","padding":{"Desktop":{"unit":"px","dimension":{"top":"30","right":"30","bottom":"30","left":"30"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf3"><div class="guten-column-wrapper" data-id="wf3">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#2edaf1"},"typography":{"fontFamily":"Orbitron","fontSize":"22px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#2edaf1;font-family:Orbitron;font-size:22px;font-weight:600;">{{feature3_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffff73"},"typography":{"fontFamily":"Inter","fontSize":"15px"}}} --><p class="has-text-color" style="color:#ffffff73;font-family:Inter;font-size:15px;">{{feature3_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
