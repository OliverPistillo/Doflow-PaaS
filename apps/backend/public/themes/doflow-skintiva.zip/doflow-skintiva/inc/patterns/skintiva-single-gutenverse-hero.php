<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Skintiva Single Gutenverse Hero', 'skintiva' ),
	'categories' => array( 'skintiva-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-vGizbB","background":{"type":"default","color":{"type":"variable","id":"theme-4"}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","bottom":"0"}},"Mobile":{"unit":"px","dimension":{"right":"0","left":"0"}}},"zIndex":{"Desktop":2}} -->
<div class="section-wrapper" data-id="vGizbB"><section class="wp-block-gutenverse-section guten-element guten-section guten-vGizbB layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-KY1kSS","margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-KY1kSS"><div class="guten-column-wrapper" data-id="KY1kSS"><!-- wp:gutenverse/section {"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-gpfdBL","background":{"type":"default","color":{"type":"variable","id":"theme-6"},"useFeaturedImage":{"Desktop":false,"previousValues":{"Tablet":"inherit"},"Tablet":false,"Mobile":false},"image":{"Desktop":[]},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"40","left":"40"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"20","bottom":"0","left":"20"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}}},"padding":{"Desktop":{"unit":"px","dimension":{"right":"70","left":"70","top":"120","bottom":"60"}},"Mobile":{"unit":"px","dimension":{"top":"60","bottom":"60","right":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="gpfdBL"><section class="wp-block-gutenverse-section guten-element guten-section guten-gpfdBL layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-1fj27g","horizontalAlign":{"Desktop":"center"},"margin":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-1fj27g"><div class="guten-column-wrapper" data-id="1fj27g"><!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-cFtHSO","margin":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="section-wrapper" data-id="cFtHSO"><section class="wp-block-gutenverse-section guten-element guten-section guten-cFtHSO layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Desktop":true,"previousValues":{"Tablet":"inherit"},"Tablet":true,"Mobile":true},"elementId":"guten-UbMthk","horizontalAlign":{"Desktop":"center"},"padding":{"Mobile":{"unit":"px","dimension":{"right":"","left":""}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-UbMthk"><div class="guten-column-wrapper" data-id="UbMthk"><!-- wp:gutenverse/post-title {"elementId":"guten-MmgJMw","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"ZgJhJW","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"48"}},"weight":"500","lineHeight":{"Desktop":{"unit":"em","point":"1"}}},"color":{"type":"variable","id":"theme-1"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"16","left":"0"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20"}}},"padding":{"Desktop":{"unit":"%","dimension":{"right":"","left":""}},"Mobile":{"unit":"px","dimension":{"right":"","left":"","top":"","bottom":""}}},"positioningType":{"Desktop":"custom"},"positioningWidth":{"Desktop":{"unit":"px","point":"810"}}} -->
<div class="guten-element guten-post-title guten-MmgJMw"></div>
<!-- /wp:gutenverse/post-title -->

<!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1320"},"isChild":true,"gap":"no","elementId":"guten-cwlRAe","margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"32","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="section-wrapper" data-id="cwlRAe"><section class="wp-block-gutenverse-section guten-element guten-section guten-cwlRAe layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-PQdK9Q","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Mobile":"center"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-PQdK9Q"><div class="guten-column-wrapper" data-id="PQdK9Q"><!-- wp:gutenverse/icon {"elementId":"guten-2NIIaJ","icon":"fas fa-user","iconAlign":{"Desktop":"center"},"iconColorOne":{"r":216,"g":82,"b":6,"a":0},"iconSize":{"Desktop":{"point":"16","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-2"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"3","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-2NIIaJ guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-user"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-author {"elementId":"guten-8enHwn","typography":{"type":"variable","id":"raqEAf","font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"400","transform":"default","decoration":"default","style":"default"},"color":{"type":"variable","id":"theme-2"},"authorBorder":{"radius":{"Desktop":[]}},"authorBorderResponsive":{"Desktop":{"radius":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"20","bottom":"6","left":"10"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"","right":"0","bottom":"0","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-author guten-8enHwn"></div>
<!-- /wp:gutenverse/post-author -->

<!-- wp:gutenverse/icon {"elementId":"guten-rVwj9z","icon":"fas fa-calendar-alt","iconAlign":{"Desktop":"center"},"iconColorOne":{"r":216,"g":82,"b":6,"a":0},"iconSize":{"Desktop":{"point":"16","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-2"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"3","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-rVwj9z guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-calendar-alt"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-date {"elementId":"guten-Guojif","typography":{"type":"variable","id":"raqEAf","font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"400","transform":"default","decoration":"default","style":"default"},"color":{"type":"variable","id":"theme-2"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","right":"20","bottom":"4","left":"10"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-Guojif"></div>
<!-- /wp:gutenverse/post-date -->

<!-- wp:gutenverse/icon {"elementId":"guten-TXbaS8","icon":"far fa-folder-open","iconAlign":{"Desktop":"center"},"iconColorOne":{"r":216,"g":82,"b":6,"a":0},"iconSize":{"Desktop":{"point":"16","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-2"},"margin":{"Desktop":[],"Mobile":{"unit":"px","dimension":{"right":"0","left":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"3","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-TXbaS8 guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="far fa-folder-open"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-terms {"elementId":"guten-jGYU10","linkTo":"term","typography":{"type":"variable","id":"raqEAf","font":{"label":"Plus Jakarta Sans","value":"Plus Jakarta Sans","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"400","transform":"default","decoration":"default","style":"default"},"color":{"type":"variable","id":"theme-2"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-4","right":"6","bottom":"0","left":"10"}},"Mobile":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-terms guten-jGYU10"></div>
<!-- /wp:gutenverse/post-terms --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Desktop":true,"previousValues":{"Tablet":"inherit"},"Tablet":true,"Mobile":true},"elementId":"guten-pGufid","background":{"type":"default","useFeaturedImage":{"Desktop":true,"previousValues":{"Tablet":"inherit"},"Tablet":true,"Mobile":true},"image":{"Desktop":{"id":"#gutenFeaturedImage","image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/img-placeholder.jpg"},"Mobile":{"id":"#gutenFeaturedImage","image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/img-placeholder.jpg"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover","Mobile":"cover"}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-pGufid guten-using-featured-image"><div class="guten-column-wrapper" data-id="pGufid"><!-- wp:gutenverse/spacer {"elementId":"guten-qOZKWx","space":{"Desktop":{"unit":"px","point":"500"},"Mobile":{"unit":"px","point":"350"}}} -->
<div class="guten-element guten-spacer guten-qOZKWx"></div>
<!-- /wp:gutenverse/spacer --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
