<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Skintiva Gutenverse Footer', 'skintiva' ),
	'categories' => array( 'skintiva-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","stickyIndex":2,"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-mibruE","background":{"type":"default","color":{"type":"variable","id":"theme-6"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"40","bottom":"40"}}},"zIndex":{"Desktop":3}} -->
<div class="section-wrapper" data-id="mibruE"><section class="wp-block-gutenverse-section guten-element guten-section guten-mibruE layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-c6Phj7"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-c6Phj7"><div class="guten-column-wrapper" data-id="c6Phj7"><!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1240"},"gap":"no","elementId":"guten-bl8bCU","padding":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"40","left":"40"}}}} -->
<div class="section-wrapper" data-id="bl8bCU"><section class="wp-block-gutenverse-section guten-element guten-section guten-bl8bCU layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Mobile":true,"previousValues":{"Mobile":"valueIsSet","Tablet":"valueIsSet"},"Tablet":true},"elementId":"guten-r61VNx","horizontalAlign":{"Desktop":"default","Mobile":"center","Tablet":"center"},"margin":{"Mobile":{"unit":"px","dimension":{"bottom":"40"}},"Tablet":{"unit":"px","dimension":{"bottom":"40","right":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-r61VNx"><div class="guten-column-wrapper" data-id="r61VNx"><!-- wp:gutenverse/image {"elementId":"guten-Fls4Hg","imgSrc":{"media":{"imageId":35,"sizes":{"thumbnail":{"height":150,"width":150,"url":"https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/skintiva-logo-color.png","orientation":"landscape"},"medium":{"height":58,"width":300,"url":"https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/skintiva-logo-color.png","orientation":"landscape"},"large":{"height":198,"width":1024,"url":"https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/skintiva-logo-color.png","orientation":"landscape"},"full":{"url":"https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/skintiva-logo-color.png","height":322,"width":1666,"orientation":"landscape"}}},"size":"full"},"altOriginal":"","captionOriginal":"","width":{"Desktop":{"unit":"px","point":"140"}},"align":{"Desktop":"left","Mobile":"center","Tablet":"center"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}}}} -->
<div class="wp-block-gutenverse-image guten-element guten-image guten-Fls4Hg"><div class="guten-image-wrapper"><img class="gutenverse-image-box-filled" src="https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/skintiva-logo-color.png" height="322" width="1666"/></div></div>
<!-- /wp:gutenverse/image -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-AlgN7G","alignment":{"Mobile":"center","Tablet":"center"},"textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":""}}},"containsAnchorTag":false,"margin":{"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"positioningType":{"Desktop":"custom","Tablet":"custom"},"positioningWidth":{"Desktop":{"unit":"px","point":"450"},"Tablet":{"unit":"px","point":"430"}}} -->
<div class="guten-element gutenverse-text-editor guten-AlgN7G"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Delivering expert dermatological care with science, precision, and purpose. Your skin journey, guided with trust, tailored expertise, and long-lasting confidence.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Mobile":true,"previousValues":{"Mobile":"valueIsSet","Tablet":"valueIsSet"},"Tablet":true},"elementId":"guten-QMfbry","horizontalAlign":{"Desktop":"default","Mobile":"center"},"margin":{"Tablet":{"unit":"px","dimension":{"bottom":"16","right":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-QMfbry"><div class="guten-column-wrapper" data-id="QMfbry"><!-- wp:gutenverse/icon-list {"elementId":"guten-y24jAd","displayInline":true,"spaceBetween":{"Tablet":"20","Desktop":"48"},"alignList":{"Desktop":"flex-end","Mobile":null,"Tablet":"center"},"iconSize":{"Desktop":"0","Tablet":"0"},"textColor":{"type":"variable","id":"theme-1"},"textColorHover":{"type":"variable","id":"theme-3"},"textIndent":{"Desktop":"0","Tablet":"0"},"textTypography":{"type":"variable","id":"LKbnG5","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","transform":"uppercase","spacing":{"Desktop":"0.1"}}} -->
<div class="guten-element guten-icon-list guten-y24jAd"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-3rXSIi","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-3rXSIi"><div class="list-divider"></div><a id="guten-3rXSIi" href="#"><i class="fas fa-check"></i><span class="list-text ">About us</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-t6r3bs","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-t6r3bs"><div class="list-divider"></div><a id="guten-t6r3bs" href="#"><i class="fas fa-check"></i><span class="list-text ">Blog</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-GgPtkL","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-GgPtkL"><div class="list-divider"></div><a id="guten-GgPtkL" href="#"><i class="fas fa-check"></i><span class="list-text ">Contact us</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->

<!-- wp:gutenverse/spacer {"elementId":"guten-ToxAvW","space":{"Desktop":{"unit":"px","point":"60"}},"hideTablet":false,"hideMobile":true} -->
<div class="guten-element guten-spacer guten-ToxAvW hide-mobile"></div>
<!-- /wp:gutenverse/spacer -->

<!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1240"},"gap":"no","elementId":"guten-sMGLkf","padding":{"Desktop":{"unit":"px","dimension":{"right":"40","left":"40"}}}} -->
<div class="section-wrapper" data-id="sMGLkf"><section class="wp-block-gutenverse-section guten-element guten-section guten-sMGLkf layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Tablet":true,"previousValues":{"Tablet":"inherit"},"Mobile":true},"elementId":"guten-Ljsvvk","margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"16","left":"0"}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-Ljsvvk"><div class="guten-column-wrapper" data-id="Ljsvvk"><!-- wp:gutenverse/icon-list {"elementId":"guten-NOw5ew","displayInline":true,"spaceBetween":{"Desktop":"24","Mobile":"0"},"alignList":{"Desktop":"flex-start","Tablet":"center"},"iconColor":{"type":"variable","id":"theme-3"},"iconColorHover":{"type":"variable","id":"theme-3"},"iconSize":{"Desktop":"14"},"textColor":{"type":"variable","id":"theme-1"},"textColorHover":{"type":"variable","id":"theme-3"},"textIndent":{"Desktop":"10","Mobile":""},"textTypography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":""}}},"margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="guten-element guten-icon-list guten-NOw5ew"><div class=" list-wrapper inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-Vsl7QQ","hasGlobalLink":true,"margin":{"Mobile":{"unit":"px","dimension":{"bottom":"16"}}}} -->
<div class="guten-element guten-icon-list-item guten-Vsl7QQ"><div class="list-divider"></div><a id="guten-Vsl7QQ" href="#"><i class="gtn gtn-envelope-light"></i><span class="list-text ">admin@support.com</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-8tbloi","hasGlobalLink":true} -->
<div class="guten-element guten-icon-list-item guten-8tbloi"><div class="list-divider"></div><a id="guten-8tbloi" href="#"><i class="fas fa-phone"></i><span class="list-text ">(+777) 123-456-7890</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div></div>
<!-- /wp:gutenverse/icon-list --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50},"forceColumnHundred":{"Tablet":true,"previousValues":{"Tablet":"inherit"},"Mobile":true},"elementId":"guten-2yOzH6","margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-2yOzH6"><div class="guten-column-wrapper" data-id="2yOzH6"><!-- wp:gutenverse/social-icons {"elementId":"guten-yKm3B0","iconSize":{"Desktop":{"unit":"px","point":"18"}},"gap":{"Desktop":"24"},"alignment":{"Desktop":"flex-end","Tablet":"center"},"iconColor":{"type":"variable","id":"theme-3"},"bgColor":{"r":0,"g":0,"b":0,"a":0},"itemPadding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"hoverIconColor":{"type":"variable","id":"theme-0"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="guten-element guten-social-icons guten-yKm3B0 rounded horizontal fill"><!-- wp:gutenverse/social-icon {"elementId":"guten-SBXv9T"} -->
<div class="guten-element guten-social-icon guten-SBXv9T instagram"><a id="guten-SBXv9T" href="#"><i class="gtn gtn-instagram-1-light"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-PIyCO8","iconSize":{"Desktop":{"unit":"px","point":""}}} -->
<div class="guten-element guten-social-icon guten-PIyCO8 facebook"><a id="guten-PIyCO8" href="#"><i class="gtn gtn-facebook-light"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-7Cluyy"} -->
<div class="guten-element guten-social-icon guten-7Cluyy twitter"><a id="guten-7Cluyy" href="#"><i class="fab fa-x-twitter"></i></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-Qs63hY"} -->
<div class="guten-element guten-social-icon guten-Qs63hY whatsapp"><a id="guten-Qs63hY" href="#"><i class="gtn gtn-whatsapp-1-light"></i></a></div>
<!-- /wp:gutenverse/social-icon --></div>
<!-- /wp:gutenverse/social-icons --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --><!-- wp:gutenverse/section {"layout":"fullwidth","sticky":{"Desktop":true},"stickyPosition":"bottom","stickyIndex":1,"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-auYi1a","background":{"type":"default","image":{"Desktop":{"id":444,"image":"https://designer.gutenverse.com/skintiva/wp-content/uploads/sites/242/2025/08/pretty-woman-eyes.jpg"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"backgroundOverlay":{"type":"gradient","gradientColor":[{"color":"rgba(0, 0, 0, 0)","active":true,"opacity":0,"id":1,"offset":"0.000"},{"color":"rgba(103, 65, 48, 1)","opacity":1,"active":false,"id":2,"offset":"0.73"}],"gradientType":"linear","gradientAngle":"170"},"opacity":"0.5","padding":{"Mobile":{"unit":"px","dimension":{"right":""}}}} -->
<div class="section-wrapper guten-section-wrapper section-guten-auYi1a sticky-bottom" data-id="auYi1a"><section class="wp-block-gutenverse-section guten-element guten-section guten-auYi1a layout-fullwidth align-stretch guten-sticky sticky-bottom"><div class="guten-data"><div data-var="stickyDataauYi1a" data-value="{&quot;sticky&quot;:{&quot;Desktop&quot;:true},&quot;stickyShowOn&quot;:&quot;both&quot;,&quot;stickyPosition&quot;:&quot;bottom&quot;,&quot;stickyEase&quot;:&quot;none&quot;,&quot;stickyDuration&quot;:0.25,&quot;topSticky&quot;:{&quot;Desktop&quot;:{&quot;point&quot;:&quot;0&quot;,&quot;unit&quot;:&quot;px&quot;}},&quot;bottomSticky&quot;:{&quot;Desktop&quot;:{&quot;point&quot;:&quot;0&quot;,&quot;unit&quot;:&quot;px&quot;}}}"></div></div><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-SQiFIe","horizontalAlign":{"Desktop":"flex-end","Mobile":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-SQiFIe"><div class="guten-column-wrapper" data-id="SQiFIe"><!-- wp:gutenverse/spacer {"elementId":"guten-CDTL4M","space":{"Desktop":{"unit":"px","point":"400"}}} -->
<div class="guten-element guten-spacer guten-CDTL4M"></div>
<!-- /wp:gutenverse/spacer -->

<!-- wp:gutenverse/icon {"elementId":"guten-jmhihS","icon":"gtn gtn-arrow-up-line","iconAlign":{"Desktop":"right","Mobile":"center"},"iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"unit":"px","point":"40"}},"iconPadding":{"Desktop":"20"},"iconColorTwo":{"type":"variable","id":"theme-4"},"iconColorHoverOne":{"type":"variable","id":"theme-0"},"iconColorHoverTwo":{"type":"variable","id":"theme-4"},"iconShape":"circle","url":"#skintiva-header","border":{"all":{"type":"solid","width":2,"color":{"r":255,"g":255,"b":255,"a":0.5}},"radius":{"Desktop":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}}}},"borderHover":{"all":{"color":{"type":"variable","id":"theme-0"},"type":"solid","width":2}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"40"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"right":""}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-jmhihS guten-icon"><a class="guten-icon-wrapper circle stacked" href="#skintiva-header"><i class="gtn gtn-arrow-up-line"></i></a></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1240"},"gap":"no","elementId":"guten-kGNWT6","border":{"top":{"type":"solid","width":1,"color":{"type":"variable","id":"theme-10"}}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20","top":"20"}}},"padding":{"Desktop":{"unit":"px","dimension":{"right":"40","left":"40","top":"20"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="kGNWT6"><section class="wp-block-gutenverse-section guten-element guten-section guten-kGNWT6 layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":55},"forceColumnHundred":{"Tablet":true,"previousValues":{"Tablet":"inherit"},"Mobile":true},"elementId":"guten-wI2bDY","margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"16","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"16","left":"0"}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wI2bDY"><div class="guten-column-wrapper" data-id="wI2bDY"><!-- wp:gutenverse/heading {"elementId":"guten-3iLJVZ","type":6,"textAlign":{"Tablet":"center"},"color":{"type":"variable","id":"theme-5"},"typography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":""}}},"containsAnchorTag":true,"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"textChilds":[{"color":{"type":"variable","id":"theme-4"},"colorHover":{"type":"variable","id":"theme-5"},"typography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":""}}},"typographyHover":[],"textClip":[],"textClipHover":[],"textStroke":[],"textStrokeHover":[],"background":[],"backgroundHover":[],"padding":[],"paddingHover":[],"margin":[],"marginHover":[],"value":[],"id":"guten-vAhsIf","spanId":"guten-PizMqI","_key":"cj3sqd"}],"openChild":"guten-vAhsIf"} -->
<h6 class="wp-block-gutenverse-heading guten-element guten-3iLJVZ">Dermatology Clinic & Skincare WordPress Theme. Powered by <span id="guten-PizMqI"><span class="guten-text-highlight guten-TmBhNS" id="guten-vAhsIf"><a href="https://gutenverse.com/" target="_blank" rel="noreferrer noopener">Gutenverse Blocks Addons</a></span></span>.</h6>
<!-- /wp:gutenverse/heading --></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":45},"forceColumnHundred":{"Tablet":true,"previousValues":{"Tablet":"inherit"},"Mobile":true},"elementId":"guten-9iCxxD","horizontalAlign":{"Desktop":"flex-end"},"margin":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Tablet":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-9iCxxD"><div class="guten-column-wrapper" data-id="9iCxxD"><!-- wp:gutenverse/heading {"elementId":"guten-vZfDMn","type":6,"textAlign":{"Desktop":"right","Tablet":"center"},"color":{"type":"variable","id":"theme-5"},"typography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":""}}},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<h6 class="wp-block-gutenverse-heading guten-element guten-vZfDMn">Copyright © 2025. All Rights Reserved</h6>
<!-- /wp:gutenverse/heading --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '[{"name":"skintiva-logo-color.png","image_url":"https:\/\/designer.gutenverse.com\/skintiva\/wp-content\/uploads\/sites\/242\/2025\/08\/skintiva-logo-color.png","type":"sync","id":912,"image_id":35},{"name":"pretty-woman-eyes.jpg","image_url":"https:\/\/designer.gutenverse.com\/skintiva\/wp-content\/uploads\/sites\/242\/2025\/08\/pretty-woman-eyes.jpg","type":"sync","id":912,"image_id":444}]',
	'is_sync' => true,
);
