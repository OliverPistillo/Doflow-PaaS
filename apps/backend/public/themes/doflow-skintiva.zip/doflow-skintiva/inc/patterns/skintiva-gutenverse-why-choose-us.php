<?php
/**
 * Pattern: Skintiva Why Choose Us — 3 features (DoFlow — icon-box PRO rimosso)
 */
return array(
    'title'      => __( 'Skintiva Why Choose Us', 'doflow-skintiva' ),
    'categories' => array( 'skintiva-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-wcu1","background":{"type":"default","color":{"type":"variable","id":"theme-4"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"100","bottom":"100"}},"Tablet":{"unit":"px","dimension":{"top":"70","right":"20","bottom":"70","left":"20"}}}} -->
<div class="section-wrapper" data-id="wcu1"><section class="wp-block-gutenverse-section guten-element guten-section guten-wcu1 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-wcu-head","horizontalAlign":{"Desktop":"center"},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"60"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wcu-head"><div class="guten-column-wrapper" data-id="wcu-head">
<!-- wp:heading {"textAlign":"center","style":{"color":{"text":"#333333"},"typography":{"fontFamily":"Cormorant Garamond","fontSize":"48px","fontWeight":"600","fontStyle":"italic"}}} --><h2 class="wp-block-heading has-text-align-center has-text-color" style="color:#333333;font-family:Cormorant Garamond;font-size:48px;font-weight:600;font-style:italic;">{{why_heading}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"16px"},"spacing":{"margin":{"top":"16px"}}}} --><p class="has-text-align-center has-text-color" style="color:#333333a6;font-family:Raleway;font-size:16px;margin-top:16px;">{{why_description}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf1","padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"36","bottom":"40","left":"36"}}},"background":{"type":"default","color":{"type":"variable","id":"theme-6"}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf1"><div class="guten-column-wrapper" data-id="wf1">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Cormorant Garamond","fontSize":"26px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Cormorant Garamond;font-size:26px;font-weight:600;">{{feature1_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#333333a6;font-family:Raleway;font-size:15px;line-height:1.7;">{{feature1_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf2","padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"36","bottom":"40","left":"36"}}},"background":{"type":"default","color":{"type":"variable","id":"theme-6"}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf2"><div class="guten-column-wrapper" data-id="wf2">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Cormorant Garamond","fontSize":"26px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Cormorant Garamond;font-size:26px;font-weight:600;">{{feature2_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#333333a6;font-family:Raleway;font-size:15px;line-height:1.7;">{{feature2_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33,"Tablet":100},"elementId":"guten-wf3","padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"36","bottom":"40","left":"36"}}},"background":{"type":"default","color":{"type":"variable","id":"theme-6"}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-wf3"><div class="guten-column-wrapper" data-id="wf3">
<!-- wp:heading {"level":3,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Cormorant Garamond","fontSize":"26px","fontWeight":"600"}}} --><h3 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Cormorant Garamond;font-size:26px;font-weight:600;">{{feature3_title}}</h3><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"15px","lineHeight":"1.7"}}} --><p class="has-text-color" style="color:#333333a6;font-family:Raleway;font-size:15px;line-height:1.7;">{{feature3_text}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
