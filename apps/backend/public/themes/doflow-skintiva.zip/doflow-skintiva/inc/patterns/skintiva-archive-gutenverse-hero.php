<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Skintiva Archive Gutenverse Hero', 'skintiva' ),
	'categories' => array( 'skintiva-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-8KiFdc","background":{"type":"default","color":{"type":"variable","id":"theme-4"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"zIndex":{"Desktop":2}} -->
<div class="section-wrapper" data-id="8KiFdc"><section class="wp-block-gutenverse-section guten-element guten-section guten-8KiFdc layout-fullwidth align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-E6kRn7","background":{"type":"default"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-E6kRn7"><div class="guten-column-wrapper" data-id="E6kRn7"><!-- wp:gutenverse/section {"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-bR1LDM","background":{"type":"default","color":{"type":"variable","id":"theme-6"}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"40","left":"40"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}}},"padding":{"Desktop":{"unit":"px","dimension":{"right":"70","left":"70","top":"120","bottom":"120"}},"Mobile":{"unit":"px","dimension":{"top":"","right":"0","bottom":"","left":"0"}}}} -->
<div class="section-wrapper" data-id="bR1LDM"><section class="wp-block-gutenverse-section guten-element guten-section guten-bR1LDM layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-VnVyVz"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-VnVyVz"><div class="guten-column-wrapper" data-id="VnVyVz"><!-- wp:gutenverse/archive-title {"elementId":"guten-UE5Xxv","alignment":{"Desktop":"flex-start","Mobile":"center"},"typography":{"type":"variable","id":"agM48N","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"64"},"Tablet":{"unit":"px","point":"56"},"Mobile":{"unit":"px","point":"48"}},"lineHeight":{"Desktop":{"unit":"em","point":"1"}},"weight":"500","spacing":{"Desktop":"-0.02"},"transform":"default","style":"default"},"color":{"type":"variable","id":"theme-1"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"positioningType":{"Tablet":"full"}} -->
<div class="guten-element guten-archive-title guten-UE5Xxv"></div>
<!-- /wp:gutenverse/archive-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
