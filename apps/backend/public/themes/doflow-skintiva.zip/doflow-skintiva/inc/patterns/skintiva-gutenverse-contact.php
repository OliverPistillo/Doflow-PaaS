<?php
/**
 * Pattern: Skintiva Contact (DoFlow — nuovo)
 */
return array(
    'title'      => __( 'Skintiva Contact', 'doflow-skintiva' ),
    'categories' => array( 'skintiva-gutenverse' ),
    'images'     => '[]',
    'is_sync'    => false,
    'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-skcont","background":{"type":"default","color":{"type":"variable","id":"theme-4"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"100","bottom":"100"}},"Tablet":{"unit":"px","dimension":{"top":"70","right":"20","bottom":"70","left":"20"}}}} -->
<div class="section-wrapper" data-id="skcont"><section class="wp-block-gutenverse-section guten-element guten-section guten-skcont layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no">

<!-- wp:gutenverse/column {"width":{"Desktop":55,"Tablet":100},"elementId":"guten-skcl","padding":{"Desktop":{"unit":"px","dimension":{"right":"60"}},"Tablet":{"unit":"px","dimension":{"right":"0","bottom":"50"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-skcl"><div class="guten-column-wrapper" data-id="skcl">
<!-- wp:heading {"style":{"color":{"text":"#333333"},"typography":{"fontFamily":"Cormorant Garamond","fontSize":"52px","fontWeight":"600","fontStyle":"italic","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"24px"}}}} --><h2 class="wp-block-heading has-text-color" style="color:#333333;font-family:Cormorant Garamond;font-size:52px;font-weight:600;font-style:italic;line-height:1.1;margin-bottom:24px;">{{contact_heading}}</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"16px","lineHeight":"1.7"},"spacing":{"margin":{"bottom":"36px"}}}} --><p class="has-text-color" style="color:#333333a6;font-family:Raleway;font-size:16px;line-height:1.7;margin-bottom:36px;">{{contact_description}}</p><!-- /wp:paragraph -->
<!-- wp:gutenverse/button {"elementId":"guten-skbtn","content":"{{contact_cta}}","paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"16","bottom":"16","right":"36","left":"36"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-3"}},"buttonBackgroundHover":{"type":"default","color":{"r":51,"g":51,"b":51,"a":1}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}}},"color":{"type":"variable","id":"theme-4"},"hoverTextColor":{"type":"variable","id":"theme-4"},"typography":{"font":{"label":"Raleway","value":"Raleway","type":"google"},"size":{"Desktop":{"unit":"px","point":"14"}},"weight":"600","transform":"uppercase","spacing":{"Desktop":"0.08"}}} -->
<div class="guten-element guten-button-wrapper guten-skbtn"><a class="guten-button guten-button-sm" href="mailto:{{contact_email}}"><span>{{contact_cta}}</span></a></div>
<!-- /wp:gutenverse/button -->
</div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":45,"Tablet":100},"elementId":"guten-skcr","padding":{"Desktop":{"unit":"px","dimension":{"left":"50"}},"Tablet":{"unit":"px","dimension":{"left":"0"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-skcr"><div class="guten-column-wrapper" data-id="skcr">
<!-- wp:heading {"level":5,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Raleway","fontSize":"11px","fontWeight":"700","letterSpacing":"0.15em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"6px"}}}} --><h5 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Raleway;font-size:11px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;margin-bottom:6px;">Email</h5><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333"},"typography":{"fontFamily":"Raleway","fontSize":"16px"},"spacing":{"margin":{"bottom":"28px"}}}} --><p class="has-text-color" style="color:#333333;font-family:Raleway;font-size:16px;margin-bottom:28px;"><a href="mailto:{{contact_email}}" style="color:#333333;text-decoration:none;">{{contact_email}}</a></p><!-- /wp:paragraph -->
<!-- wp:heading {"level":5,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Raleway","fontSize":"11px","fontWeight":"700","letterSpacing":"0.15em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"6px"}}}} --><h5 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Raleway;font-size:11px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;margin-bottom:6px;">Telefono</h5><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333"},"typography":{"fontFamily":"Raleway","fontSize":"16px"},"spacing":{"margin":{"bottom":"28px"}}}} --><p class="has-text-color" style="color:#333333;font-family:Raleway;font-size:16px;margin-bottom:28px;">{{contact_phone}}</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":5,"style":{"color":{"text":"#a9694e"},"typography":{"fontFamily":"Raleway","fontSize":"11px","fontWeight":"700","letterSpacing":"0.15em","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"6px"}}}} --><h5 class="wp-block-heading has-text-color" style="color:#a9694e;font-family:Raleway;font-size:11px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;margin-bottom:6px;">Indirizzo</h5><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#333333a6"},"typography":{"fontFamily":"Raleway","fontSize":"16px"}}} --><p class="has-text-color" style="color:#333333a6;font-family:Raleway;font-size:16px;">{{contact_address}}</p><!-- /wp:paragraph -->
</div></div>
<!-- /wp:gutenverse/column -->

</div></section></div>
<!-- /wp:gutenverse/section -->',
);
