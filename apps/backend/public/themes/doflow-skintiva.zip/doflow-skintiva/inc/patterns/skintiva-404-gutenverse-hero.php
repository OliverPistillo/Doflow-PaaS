<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Skintiva 404 Gutenverse Hero', 'skintiva' ),
	'categories' => array( 'skintiva-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"600"},"elementId":"guten-UKKeQf","heightControl":"fit","align":"middle","verticalAlign":"center","background":{"type":"default","color":{"type":"variable","id":"theme-6"}},"padding":{"Tablet":{"unit":"px","dimension":{"right":"20","left":"20"}}},"zIndex":{"Desktop":2}} -->
<div class="section-wrapper" data-id="UKKeQf"><section class="wp-block-gutenverse-section guten-element guten-section guten-UKKeQf layout-boxed align-middle"><div class="guten-container guten-column-gap-default"><!-- wp:gutenverse/column {"width":{"Desktop":100},"sectionVerticalAlign":"center","elementId":"guten-ymtfFQ","horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-ymtfFQ"><div class="guten-column-wrapper" data-id="ymtfFQ"><!-- wp:gutenverse/heading {"elementId":"guten-UrcEbx","type":1,"textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"theme-3"},"typography":{"type":"variable","id":"53W4lu","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"99"}},"weight":"500","transform":"default"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"20","left":"0"}}}} -->
<h1 class="wp-block-gutenverse-heading guten-element guten-UrcEbx">404</h1>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/heading {"elementId":"guten-DCbr3Z","type":4,"textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"dxlWQE","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"24"},"Mobile":{"unit":"px","point":"20"},"Tablet":{"unit":"px","point":"20"}},"weight":"500","lineHeight":{"Desktop":{"unit":"em","point":"1.4"},"Mobile":{"unit":"px"}}},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"20","left":"0"}}}} -->
<h4 class="wp-block-gutenverse-heading guten-element guten-DCbr3Z">Page Not Found</h4>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-GtsJkW","alignment":{"Desktop":"center"},"textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"JhY17Q","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","spacing":{"Desktop":""},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"}}},"containsAnchorTag":false,"positioningType":{"Desktop":"custom","Mobile":"full"},"positioningWidth":{"Desktop":{"unit":"px","point":"445"}}} -->
<div class="guten-element gutenverse-text-editor guten-GtsJkW"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Oops! The page you’re looking for can’t be found. But don’t worry, your journey to glowing skin continues here.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/button {"elementId":"guten-FIpo2E","content":"back to home","buttonWidth":{"Desktop":""},"alignButton":{"Desktop":"center"},"paddingButton":{"Desktop":{"unit":"px","dimension":{"right":"24","left":"24","top":"12","bottom":"12"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-3"}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"theme-0"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}}}},"showIcon":true,"icon":"gtn gtn-arrow-up-right-line","iconPosition":"after","iconSpacing":{"Desktop":"10"},"iconSize":{"Desktop":{"unit":"px","point":"22"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"40"}}},"color":{"type":"variable","id":"theme-4"},"iconColor":{"type":"variable","id":"theme-4"},"typography":{"type":"variable","id":"gQf8FO","font":{"label":"Manrope","value":"Manrope","type":"google"},"size":{"Desktop":{"unit":"px","point":"16"}},"weight":"400","transform":"uppercase","spacing":{"Desktop":"0.1"}}} -->
<div class="guten-element guten-button-wrapper guten-FIpo2E"><a class="guten-button guten-button-sm" href="#"><span>back to home</span><i class="fa-lg gtn gtn-arrow-up-right-line"></i></a></div>
<!-- /wp:gutenverse/button --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
