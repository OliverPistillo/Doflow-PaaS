<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Skintiva Page Gutenverse Content', 'skintiva' ),
	'categories' => array( 'skintiva-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1240"},"gap":"no","elementId":"guten-05UMsd","background":{"type":"default","color":{"type":"variable","id":"theme-4"}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"100","bottom":"100"}}},"zIndex":{"Desktop":2}} -->
<div class="section-wrapper" data-id="05UMsd"><section class="wp-block-gutenverse-section guten-element guten-section guten-05UMsd layout-boxed align-stretch"><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-LWZx3F"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-LWZx3F"><div class="guten-column-wrapper" data-id="LWZx3F"><!-- wp:gutenverse/post-content {"elementId":"guten-NKN7OB"} -->
<div class="guten-element guten-post-content guten-NKN7OB"></div>
<!-- /wp:gutenverse/post-content --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'images'      => '',
	'is_sync' => false,
);
