=== Skintiva ===
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4

== Description ==
Skintiva is a modern dermatology and beauty clinic website theme, designed for skin specialists, aesthetic clinics, and skincare providers.

== Changelog ==

= Version 1.0.0 =
* Initial release