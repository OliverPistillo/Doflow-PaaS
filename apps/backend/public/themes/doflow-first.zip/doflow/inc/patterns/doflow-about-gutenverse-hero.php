<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'doflow About Gutenverse Hero', 'doflow' ),
	'categories' => array( 'doflow-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","gap":"no","elementId":"guten-unzFDu","background":{"type":"gradient","gradientColor":[{"color":"rgba(250, 244, 255, 1)","active":true,"opacity":1,"id":1,"offset":"0.000"},{"color":"rgba(161, 122, 255, 1)","opacity":1,"active":false,"id":2,"offset":"1.000"}]},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":"{image|other|19|url}","image":"{image|other|19|url}"}},"position":{"Desktop":"custom","Tablet":"top center","Mobile":"top center"},"repeat":{"Desktop":"no-repeat","Mobile":"no-repeat","Tablet":"no-repeat"},"size":{"Desktop":"cover","Tablet":"cover","Mobile":"cover"},"yposition":{"Desktop":{"unit":"px","point":"-250"},"Tablet":{"unit":"px","point":"0"}},"xposition":{"Desktop":{"unit":"px"},"Tablet":{"unit":"px"}},"width":{"Tablet":{"unit":"px","point":""}},"fetchPriorityHigh":true},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"24","right":"24","bottom":"24","left":"24"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"20","left":"20","top":"0","bottom":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"15","bottom":"0","left":"15"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"140","right":"0","bottom":"140","left":"0"}},"Tablet":{"unit":"px","dimension":{"top":"100","bottom":"100","right":"0","left":"0"}},"Mobile":{"unit":"px","dimension":{"top":"70","right":"0","bottom":"70","left":"0"}}}} -->
<div class="section-wrapper" data-id="unzFDu"><section class="wp-block-gutenverse-section guten-element guten-section guten-unzFDu layout-fullwidth align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-ZUUmFy","horizontalAlign":{"Desktop":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-ZUUmFy"><div class="guten-column-wrapper" data-id="ZUUmFy"><!-- wp:gutenverse/wrapper {"elementId":"guten-RHZQZo","displayType":"flex","displayWidth":{"Desktop":{"unit":"px","point":"800"}},"displayHeight":{"Desktop":{"unit":"px"}},"horizontalAlign":{"Desktop":"center","Tablet":false,"Mobile":false},"verticalAlign":{"Desktop":"default","Tablet":false,"Mobile":false}} -->
<div class="guten-element guten-wrap-helper no-margin guten-RHZQZo flex"><div class="guten-inner-wrap" data-id="RHZQZo"><!-- wp:gutenverse/heading {"elementId":"guten-UZt3vl","type":1,"textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"gv-color-text-primary"},"typography":{"type":"variable","id":"gv-font-primary","lineHeight":{"Desktop":{"unit":"em","point":"1.2"},"Tablet":{"unit":"px"},"Mobile":{"unit":"px"}},"size":{"Desktop":{"unit":"px","point":"64"},"Tablet":{"unit":"px","point":"48"},"Mobile":{"unit":"px","point":"40"}},"font":{"label":"Sora","value":"Sora","type":"google"},"weight":"600"},"containsAnchorTag":false,"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"16","left":"0"}}},"positioningType":{"Desktop":"custom","Tablet":"custom","Mobile":"custom"},"positioningWidth":{"Desktop":{"unit":"%","point":"64"},"Tablet":{"unit":"%","point":"62"},"Mobile":{"unit":"%","point":"95"}}} -->
<h1 class="wp-block-gutenverse-heading guten-element guten-UZt3vl">{{about_heading}}</h1>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-HDeKSy","gap":{"Desktop":{"unit":"px"}},"textIndent":{"Desktop":{"unit":"px"}},"alignment":{"Desktop":"center"},"textColor":{"type":"variable","id":"gv-color-text-secondary"},"typography":{"type":"variable","id":"gv-font-text","lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"px"},"Mobile":{"unit":"px"}},"size":{"Desktop":{"unit":"px","point":"18"},"Tablet":{"unit":"px","point":"17"},"Mobile":{"unit":"px","point":"16"}},"font":{"label":"Sora","value":"Sora","type":"google"},"weight":"400"},"containsAnchorTag":false,"positioningType":{"Desktop":"custom","Mobile":"custom","Tablet":"custom"},"positioningWidth":{"Desktop":{"unit":"%","point":"77"},"Mobile":{"unit":"%","point":"90"},"Tablet":{"unit":"%","point":"78"}}} -->
<div class="guten-element gutenverse-text-editor guten-HDeKSy"><div class="text-content-inner"><!-- wp:paragraph -->
<p>{{about_description}}</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor --></div></div>
<!-- /wp:gutenverse/wrapper --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'image_importer_ver' => '2.0.0',
	'images'      => '{"https:\/\/fse.jegtheme.com\/doflow\/wp-content\/uploads\/sites\/138\/2026\/03\/hero-pattern-fade.webp":{"pattern":["{image|other|19|url}"]}}',
	'is_sync' => false,
);
