<?php return array('dependencies' => array('wp-hooks'), 'version' => '0b6dceaee8798037ac75');
