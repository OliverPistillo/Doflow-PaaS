<?php
/**
 * Theme Functions
 *
 * @author Jegtheme
 * @package doflow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'doflow_VERSION' ) || define( 'doflow_VERSION', '1.0.0' );
defined( 'doflow_DIR' ) || define( 'doflow_DIR', trailingslashit( get_template_directory() ) );

defined( 'GUTENVERSE_COMPANION_REQUIRED_VERSION' ) || define( 'GUTENVERSE_COMPANION_REQUIRED_VERSION', '2.0.2' );
defined( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION' ) || define( 'GUTENVERSE_FRAMEWORK_REQUIRED_VERSION', '2.0.0' );

require get_parent_theme_file_path( 'inc/autoload.php' );

doflow\Init::instance();
