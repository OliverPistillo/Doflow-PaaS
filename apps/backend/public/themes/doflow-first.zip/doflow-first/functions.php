<?php
/**
 * DoFlow Starter — Theme Functions
 * Standalone FSE theme. Zero dependencies on Gutenverse or any external plugin.
 *
 * @package doflow-first
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DOFLOW_VERSION', '1.0.0' );
define( 'DOFLOW_DIR',     trailingslashit( get_template_directory() ) );
define( 'DOFLOW_URI',     trailingslashit( get_template_directory_uri() ) );

require_once DOFLOW_DIR . 'inc/class/class-block-patterns.php';
require_once DOFLOW_DIR . 'inc/class/class-asset-enqueue.php';

/**
 * Theme setup
 */
add_action( 'after_setup_theme', function () {
    load_theme_textdomain( 'doflow-first', DOFLOW_DIR . 'languages' );

    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
} );

/**
 * Register block patterns on init
 */
add_action( 'init', function () {
    new \doflow\Block_Patterns();
}, 9 );

/**
 * Enqueue styles
 */
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'doflow-style', get_stylesheet_uri(), array(), DOFLOW_VERSION );
    // Sora font from Google
    wp_enqueue_style(
        'doflow-google-fonts',
        'https://fonts.googleapis.com/css2?family=Sora:wght@400;600&display=swap',
        array(),
        null
    );
} );
