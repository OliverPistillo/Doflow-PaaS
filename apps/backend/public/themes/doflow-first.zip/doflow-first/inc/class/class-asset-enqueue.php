<?php
/**
 * DoFlow Asset Enqueue — standalone, no Gutenverse required.
 *
 * @package doflow-first
 */

namespace doflow;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Asset_Enqueue {

    public function __construct() {
        add_action( 'wp_enqueue_scripts',   array( $this, 'enqueue_frontend' ), 20 );
        add_action( 'enqueue_block_assets', array( $this, 'enqueue_frontend' ) );
    }

    public function enqueue_frontend(): void {
        wp_enqueue_style(
            'doflow-style',
            get_stylesheet_uri(),
            array(),
            DOFLOW_VERSION
        );

        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }
    }
}
