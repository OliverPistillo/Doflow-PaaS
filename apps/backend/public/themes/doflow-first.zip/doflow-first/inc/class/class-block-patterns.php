<?php
/**
 * DoFlow Block Patterns — standalone, no Gutenverse required.
 *
 * @package doflow-first
 */

namespace doflow;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Block_Patterns {

    public function __construct() {
        $this->register_categories();
        $this->register_patterns();
    }

    /**
     * Register pattern categories.
     */
    private function register_categories(): void {
        $categories = array(
            'doflow-home'    => __( 'DoFlow — Home',    'doflow-first' ),
            'doflow-about'   => __( 'DoFlow — About',   'doflow-first' ),
            'doflow-service' => __( 'DoFlow — Service', 'doflow-first' ),
            'doflow-faq'     => __( 'DoFlow — FAQ',     'doflow-first' ),
            'doflow-contact' => __( 'DoFlow — Contact', 'doflow-first' ),
            'doflow-global'  => __( 'DoFlow — Global',  'doflow-first' ),
        );

        foreach ( $categories as $slug => $label ) {
            if ( ! \WP_Block_Pattern_Categories_Registry::get_instance()->is_registered( $slug ) ) {
                register_block_pattern_category( $slug, array( 'label' => $label ) );
            }
        }
    }

    /**
     * All pattern files to register.
     * Add or remove entries here to control what appears in the inserter.
     */
    private function get_pattern_files(): array {
        return array(
            // Home
            'doflow-home-gutenverse-hero',
            'doflow-home-gutenverse-clients',
            'doflow-home-gutenverse-services',
            'doflow-home-gutenverse-process',
            'doflow-home-gutenverse-pricing',
            'doflow-home-gutenverse-faq',
            'doflow-home-gutenverse-blog',
            'doflow-home-gutenverse-projects',
            // Global
            'doflow-gutenverse-benefit',
            'doflow-gutenverse-testimonials',
            'doflow-gutenverse-cta',
            'doflow-gutenverse-faq',
            'doflow-gutenverse-process',
            'doflow-gutenverse-blog',
            'doflow-gutenverse-header',
            'doflow-gutenverse-footer',
            // About
            'doflow-about-gutenverse-hero',
            'doflow-about-gutenverse-who-we',
            'doflow-about-gutenverse-goals',
            'doflow-about-gutenverse-journey',
            'doflow-about-gutenverse-team',
            // Service
            'doflow-service-gutenverse-hero',
            'doflow-service-gutenverse-services',
            'doflow-service-gutenverse-pricing',
            'doflow-service-gutenverse-testimonials',
            // FAQ
            'doflow-faq-gutenverse-hero',
            'doflow-faq-gutenverse-general',
            'doflow-faq-gutenverse-pricing',
            'doflow-faq-gutenverse-service',
            // Contact
            'doflow-contact-gutenverse-hero',
            'doflow-contact-gutenverse-information',
            // Project
            'doflow-project-gutenverse-hero',
            'doflow-project-gutenverse-project-list',
            'doflow-project-gutenverse-process',
            'doflow-project-gutenverse-pricing',
            // Misc
            'doflow-blog-gutenverse-hero',
            'doflow-single-gutenverse-hero',
            'doflow-single-gutenverse-blog-content',
            'doflow-archive-gutenverse-hero',
            'doflow-index-gutenverse-hero',
            'doflow-search-gutenverse-hero',
            'doflow-search-gutenverse-search-bar',
            'doflow-404-gutenverse-error',
            'doflow-page-gutenverse-hero',
        );
    }

    /**
     * Register all patterns from their PHP files.
     */
    private function register_patterns(): void {
        $patterns_dir = DOFLOW_DIR . 'inc/patterns/';

        foreach ( $this->get_pattern_files() as $slug ) {
            $file = $patterns_dir . $slug . '.php';

            if ( ! file_exists( $file ) ) {
                continue;
            }

            $pattern_data = require $file;

            if ( ! is_array( $pattern_data ) || empty( $pattern_data['content'] ) ) {
                continue;
            }

            // Ensure required fields
            $pattern_data['slug']       = 'doflow/' . $slug;
            $pattern_data['categories'] = $pattern_data['categories'] ?? array( 'doflow-global' );

            // Remove Gutenverse-specific keys that WP core doesn't understand
            unset( $pattern_data['images'], $pattern_data['image_importer_ver'], $pattern_data['is_sync'] );

            register_block_pattern( 'doflow/' . $slug, $pattern_data );
        }
    }
}
