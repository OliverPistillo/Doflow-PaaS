<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sptizeo Search Gutenverse Hero', 'doflow-first' ),
	'categories' => array( 'doflow-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"layout":"fullwidth","width":{"Desktop":"1200"},"gap":"no","elementId":"guten-8KhA9B","background":{"type":"gradient","gradientColor":[{"color":"rgba(244, 231, 255, 1)","opacity":1,"active":false,"id":1,"offset":"0.000"},{"color":"rgba(161, 122, 255, 1)","active":true,"opacity":1,"id":2,"offset":"1.000"}]},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/hero-pattern-fade.webp","image":"' . esc_url( trailingslashit( get_template_directory_uri() ) ) . 'assets/img/hero-pattern-fade.webp"}},"repeat":{"Desktop":"no-repeat","Tablet":"no-repeat"},"position":{"Desktop":"custom","Tablet":"top center"},"size":{"Desktop":"cover"},"width":{"Desktop":{"unit":"px","point":""}},"yposition":{"Desktop":{"unit":"px","point":"-250"}},"xposition":{"Desktop":{"unit":"px"},"Tablet":{"unit":"px"}}},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"24","right":"24","bottom":"24","left":"24"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"20","left":"20","top":"0","bottom":"0"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20","top":"0","bottom":"0"}},"Mobile":{"unit":"px","dimension":{"right":"15","left":"15","top":"0","bottom":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"140","bottom":"140","right":"0","left":"0"}},"Tablet":{"unit":"px","dimension":{"right":"0","left":"0","top":"100","bottom":"100"}},"Mobile":{"unit":"px","dimension":{"right":"0","left":"0","top":"70","bottom":"70"}}}} -->
<div class="section-wrapper" data-id="8KhA9B"><section class="wp-block-gutenverse-section guten-element guten-section guten-8KhA9B layout-fullwidth align-stretch"><div class="guten-background-overlay"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-xrMAGB"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-xrMAGB"><div class="guten-column-wrapper" data-id="xrMAGB"><!-- wp:gutenverse/search-result-title {"elementId":"guten-IXg3aT","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"gv-font-primary","lineHeight":{"Desktop":{"unit":"em","point":"1.2"},"Tablet":{"unit":"px"},"Mobile":{"unit":"px"}},"size":{"Desktop":{"unit":"px","point":"64"},"Tablet":{"unit":"px","point":"48"},"Mobile":{"unit":"px","point":"40"}},"font":{"label":"Sora","value":"Sora","type":"google"},"weight":"600"},"color":{"type":"variable","id":"gv-color-text-primary"}} -->
<div class="guten-element guten-search-result-title guten-IXg3aT"></div>
<!-- /wp:gutenverse/search-result-title --></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
	'image_importer_ver' => '2.0.0',
	'images'      => '',
	'is_sync' => false,
);
